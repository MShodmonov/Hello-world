package food.delivery.controller;


import food.delivery.payloads.CategoryPayload;
import food.delivery.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @PostMapping("/save/all")
    public void saveAll(@RequestBody List<List<CategoryPayload>> list){
        categoryService.saveAll(list);
    }

    @PostMapping("/update/all")
    public void updateAll(@RequestBody List<List<CategoryPayload>> list){
        categoryService.updateAll(list);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        categoryService.delete(id);
    }

    @GetMapping("/{id}")
    public List<CategoryPayload> getById(@PathVariable Long id){
        return categoryService.getById(id);
    }

    @GetMapping("/all")
    public Page<CategoryPayload> getAll(@RequestParam Integer page, @RequestParam Integer size){
        return categoryService.getAll(page, size);
    }
}
