package food.delivery.controller;



import food.delivery.entity.User;
import food.delivery.payloads.AuthenticationRequestDto;
import food.delivery.security.JwtTokenProvider;
import food.delivery.service.AuthService;
import food.delivery.utils.DefaultData;
import food.delivery.utils.Settings;
import food.delivery.utils.TokenInfo;
import food.delivery.utils.TokenStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

@RestController
@RequestMapping(value = "/api/v1/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;
    private final AuthService authService;


    @Autowired
    public AuthController(AuthenticationManager authenticationManager,
                          JwtTokenProvider jwtTokenProvider,
                          AuthService authService) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
        this.authService = authService;
    }

    @PostMapping("/signin")
    public ResponseEntity signin(@RequestBody AuthenticationRequestDto requestDto) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(requestDto.getUsername(), requestDto.getPassword()));

            User user = (User) auth.getPrincipal();

            return ResponseEntity.ok(jwtTokenProvider.createToken(user));
        } catch (AuthenticationException e) {
            throw new BadCredentialsException("Invalid username or password");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity logout() {

        DefaultData defaultData = Settings.getDefaultData();

        TokenInfo tokenInfo = TokenStore.findByTokenId(defaultData.getTokenId());

        TokenStore.remove(tokenInfo);

        return ResponseEntity.ok().build();
    }

    @PostMapping("/refresh")
    public ResponseEntity refresh() {
        DefaultData defaultData = Settings.getDefaultData();

        TokenInfo tokenInfo = TokenStore.findByTokenId(defaultData.getTokenId());

        TokenStore.remove(tokenInfo);

        User user = authService.findUserByUsername(defaultData.getUsername());

        return ResponseEntity.ok(jwtTokenProvider.createToken(user));
    }



    @PostMapping("/verify-token")
    public ResponseEntity verify() {

        DefaultData defaultData = Settings.getDefaultData();

        User user = authService.findUserByUsername(defaultData.getUsername());

        return ResponseEntity.ok(user);
    }

    @GetMapping("/save/user")
    public void saveNewUser(@Valid @Pattern(regexp = "^\\d{12}$") @RequestParam String phoneNumber, @RequestParam(defaultValue = "User") String fullname) {
        authService.saveNewUser(phoneNumber, fullname);
    }

    @PreAuthorize("hasRole('OPERATOR')")
    @GetMapping("/save/restaurant")
    public void saveRestaurant(@Valid @Pattern(regexp = "^\\d{12}$") @RequestParam String phoneNumber, @RequestParam(defaultValue = "User") String fullname, @RequestParam String password) {
        authService.saveNewRestaurant(phoneNumber, fullname, password);
    }

    @PreAuthorize("hasRole('OPERATOR')")
    @GetMapping("/save/driver")
    public void saveDriver(@Valid @Pattern(regexp = "^\\d{12}$") @RequestParam String phoneNumber, @RequestParam(defaultValue = "User") String fullname, @RequestParam String password) {
        authService.saveNewDriver(phoneNumber, fullname, password);
    }

    @GetMapping("/activate")
    public void activate(@Valid @Pattern(regexp = "^\\d{12}$") @RequestParam String phoneNumber, @RequestParam String code) {
        authService.activateUser(code, phoneNumber);
    }

    @GetMapping("/restore")
    public void restorePassword(@Valid @Pattern(regexp = "^\\d{12}$") @RequestParam String phoneNumber) {
        authService.restoreUser(phoneNumber);
    }
    @GetMapping("/check")
    public Boolean check(@Valid @Pattern(regexp = "^\\d{12}$") @RequestParam String phoneNumber) {
        return authService.checkUser(phoneNumber);
    }



}
