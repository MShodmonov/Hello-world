package food.delivery.controller;


import food.delivery.entity.User;
import food.delivery.payloads.AddressPayload;
import food.delivery.security.CurrentUser;
import food.delivery.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/user")
public class UserController {

    @Autowired
    private AddressService addressService;

    @GetMapping("/current/{id}")
    public void makeCurrent(@PathVariable Long id, @CurrentUser User user){
        addressService.makeCurrent(id, user);
    }

    @GetMapping("/all")
    public List<AddressPayload> getUserAddress(@CurrentUser User user){
        return addressService.getAddresses(user);
    }

}
