package food.delivery.controller;


import com.google.maps.errors.ApiException;
import food.delivery.service.GoogleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequestMapping(value = "/api/v1/google")
public class GoogleTestController {

    @Autowired
    private GoogleService googleService;

    @GetMapping("/")
    public void test() throws InterruptedException, ApiException, IOException {
        googleService.testDistance();
    }
}
