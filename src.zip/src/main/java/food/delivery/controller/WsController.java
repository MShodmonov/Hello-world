package food.delivery.controller;

import food.delivery.payloads.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/websocket")
public class WsController {

    @Autowired
    SimpMessagingTemplate template;


    @PreAuthorize("hasRole('OPERATOR')")
    @PostMapping("/order")
    public Boolean send(@RequestBody Message textMessage) {
        template.convertAndSend("/topic/order", textMessage);
        return Boolean.TRUE;
    }

    @PreAuthorize("hasRole('OPERATOR')")
    @MessageMapping("/allOrder")
    @SendTo("/topic/order")
    public Message sendMessage(Message message) {
        return message;
    }


    @PreAuthorize("hasRole('USER')")
    @PostMapping("/send/user/{userId}")
    public Boolean sendUser2(@RequestBody Message textMessage, @PathVariable Long userId) {
        template.convertAndSend("/topic/user/"+userId.toString(), textMessage);
        return Boolean.TRUE;
    }

    @PreAuthorize("hasRole('USER')")
    @MessageMapping("/user-channel")
    @SendTo("/topic/user/{userId}")
    public void sendMessageUser(@DestinationVariable Long userId) {

    }

    @PreAuthorize("hasRole('DRIVER')")
    @PostMapping("/send/driver/{userId}")
    public Boolean sendDriver(@RequestBody Message textMessage, @PathVariable Long userId) {
        template.convertAndSend("/topic/driver/"+userId.toString(), textMessage);
        return Boolean.TRUE;
    }

    @PreAuthorize("hasRole('DRIVER')")
    @MessageMapping("/driver-channel")
    @SendTo("/topic/driver/{userId}")
    public void sendMessageDriver(@DestinationVariable Long userId) {

    }

    @PreAuthorize("hasRole('RESTAURANT')")
    @PostMapping("/send/restaurant/{userId}")
    public Boolean sendRestaurant(@RequestBody Message textMessage, @PathVariable Long userId) {
        template.convertAndSend("/topic/restaurant/"+userId.toString(), textMessage);
        return Boolean.TRUE;
    }

    @PreAuthorize("hasRole('RESTAURANT')")
    @MessageMapping("/restaurant-channel")
    @SendTo("/topic/restaurant/{userId}")
    public void sendMessageRestaurant(@DestinationVariable Long userId) {

    }
}
