package food.delivery.controller;

import food.delivery.payloads.FoodPayload;
import food.delivery.payloads.FoodPayloadAdmin;
import food.delivery.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/food")
public class FoodController {

    @Autowired
    private FoodService foodService;

    @PostMapping("/save/all")
    public void saveAll(@RequestBody List<List<FoodPayload>> list) {
        foodService.save(list);
    }

    @PostMapping("/update/all")
    public void updateAll(@RequestBody List<List<FoodPayload>> list) {
        foodService.update(list);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        foodService.delete(id);
    }

    @GetMapping("/restaurant/{restaurantId}")
    public Page<FoodPayload> getAllWithRestaurantId(@PathVariable Long restaurantId, @RequestParam Integer page, @RequestParam Integer size) {
        return foodService.getAllWithRestaurantId(restaurantId, page, size);
    }

    @GetMapping("operator/restaurant/{restaurantId}")
    public Page<FoodPayloadAdmin> getAllWithRestaurantIdOperator(@PathVariable Long restaurantId, @RequestParam Integer page, @RequestParam Integer size) {
        return foodService.getAllWithRestaurantIdOperator(restaurantId, page, size);
    }
}

