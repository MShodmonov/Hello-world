package food.delivery.controller;

import food.delivery.payloads.FoodPayload;
import food.delivery.payloads.FoodPayloadAdmin;
import food.delivery.payloads.RestaurantPayload;
import food.delivery.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@PreAuthorize("hasRole('OPERATOR') or hasRole('OWNER')")
@RestController
@RequestMapping(value = "/api/v1/food")
public class FoodController {

    @Autowired
    private FoodService foodService;

    @PostMapping("/save/all")
    public void saveAll(@RequestBody List<List<FoodPayload>> list) {
        foodService.save(list);
    }

    @PostMapping("/update/all")
    public void updateAll(@RequestBody List<List<FoodPayload>> list) {
        foodService.update(list);
    }

    @GetMapping("/restaurant/{restaurantId}")
    public Page<FoodPayload> getAllWithRestaurantId(@PathVariable Long restaurantId, @RequestParam Integer page, @RequestParam Integer size) {
        return foodService.getAllWithRestaurantId(restaurantId, page, size);
    }

    @GetMapping("operator/restaurant/{restaurantId}")
    public Page<FoodPayloadAdmin> getAllWithRestaurantIdOperator(@PathVariable Long restaurantId, @RequestParam Integer page, @RequestParam Integer size) {
        return foodService.getAllWithRestaurantIdOperator(restaurantId, page, size);
    }

    @GetMapping("/{id}")
    public List<FoodPayloadAdmin> getWithId(@PathVariable Long id){
        return foodService.getWithId(id);
    }
}
