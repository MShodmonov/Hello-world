package food.delivery.controller;


import food.delivery.entity.ProjectConstants;
import food.delivery.entity.User;
import food.delivery.security.CurrentUser;
import food.delivery.service.ConstantsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@PreAuthorize("hasRole('OPERATOR') or hasRole('OWNER')")
@RestController
@RequestMapping(value = "/api/v1/constant")
public class ConstantController {

    @Autowired
    private ConstantsService constantsService;

    @PostMapping("/update")
    public void saveOrUpdate(@RequestBody ProjectConstants constant){
        constantsService.saveOrUpdate(constant);
    }

    @GetMapping("/")
    public ProjectConstants get(){
        return constantsService.get();
    }
}
