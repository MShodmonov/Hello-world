package food.delivery.controller;



import food.delivery.exceptions.BadRequestException;
import food.delivery.exceptions.PersistenceException;
import food.delivery.exceptions.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionController {

    @ExceptionHandler(BadRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public BadRequestException badRequestException(BadRequestException e){
        return e;
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.FAILED_DEPENDENCY)
    public ResourceNotFoundException resourceNotFoundException(ResourceNotFoundException e){
        return e;
    }


    @ExceptionHandler(PersistenceException.class)
    @ResponseStatus(HttpStatus.PARTIAL_CONTENT)
    public PersistenceException persistenceException(PersistenceException e){
        return e;
    }


}