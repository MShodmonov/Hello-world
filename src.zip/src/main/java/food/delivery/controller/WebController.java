package food.delivery.controller;


import food.delivery.payloads.*;
import food.delivery.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/web/")
public class WebController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private RestaurantService restaurantService;

    @Autowired
    private DiscountService discountService;

    @Autowired
    private FoodService foodService;

    @Autowired
    private FoodAdditionService foodAdditionService;

    @GetMapping("/category/")
    public Page<CategoryPayload> getAllCategory(@RequestParam Integer page, @RequestParam Integer size) {
        return categoryService.getAll(page, size);
    }

    @GetMapping("/restaurant/")
    public Page<RestaurantPayload> getAllRestaurant(@RequestParam Integer page, @RequestParam Integer size) {
        return restaurantService.getAll(page, size);
    }

    @GetMapping("/discount/restaurant/{restaurantId}")
    public List<DiscountPayload> getAllWithRestaurant(@PathVariable Long restaurantId) {
        return discountService.getAllWithRestaurant(restaurantId);
    }

    @GetMapping("/food/restaurant/{restaurantId}")
    public Page<FoodPayload> getAllWithRestaurantId(@PathVariable Long restaurantId, @RequestParam Integer page, @RequestParam Integer size) {
        return foodService.getAllWithRestaurantId(restaurantId, page, size);
    }

    @GetMapping("/food-addition/food/{foodId}")
    public List<FoodAdditionPayload> getAllWithFoodId(@PathVariable Long foodId){
        return foodAdditionService.getAllWithFoodId(foodId);
    }
}




