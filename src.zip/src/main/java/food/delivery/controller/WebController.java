package food.delivery.controller;


import food.delivery.entity.User;
import food.delivery.payloads.*;
import food.delivery.security.CurrentUser;
import food.delivery.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping(value = "/api/v1/web")
public class WebController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private DiscountService discountService;

    @Autowired
    private FileStorageService fileStorageService;

    @Autowired
    private FoodAdditionService foodAdditionService;

    @Autowired
    private FoodService foodService;

    @Autowired
    private LocalCategoryService localCategoryService;

    @Autowired
    private RestaurantService restaurantService;

    @Autowired
    private OrderService orderService;

    @GetMapping("/category/all")
    public Page<CategoryPayload> getAll(@RequestParam Integer page, @RequestParam Integer size){
        return categoryService.getAll(page, size);
    }

    @GetMapping("/discount/restaurant/{restaurantId}")
    public List<DiscountPayload> getAllWithRestaurant(@PathVariable Long restaurantId){
        return discountService.getAllWithRestaurant(restaurantId);
    }

    @GetMapping("/file/{id}")
    public ResponseEntity<Resource> downloadFileById(@PathVariable UUID id, HttpServletRequest httpServletRequest) {
        return fileStorageService.downloadFile(id.toString(), httpServletRequest);
    }

    @GetMapping("/food-addition/food/{foodId}")
    public List<FoodAdditionPayload> getAllWithFoodId(@PathVariable Long foodId){
        return foodAdditionService.getAllWithFoodId(foodId);
    }

    @GetMapping("/food/restaurant/{restaurantId}")
    public Page<FoodPayload> getAllWithRestaurantId(@PathVariable Long restaurantId, @RequestParam Integer page, @RequestParam Integer size) {
        return foodService.getAllWithRestaurantId(restaurantId, page, size);
    }

    @GetMapping("/local-category/restaurant/{restaurantId}")
    public List<LocalCategoryPayload> getAllLocalCategory(@PathVariable Long restaurantId) {
        return localCategoryService.getAllWithRestaurantId(restaurantId);
    }

    @GetMapping("/restaurant/all")
    public Page<RestaurantPayload> getAllRestaurants(@RequestParam Integer page, @RequestParam Integer size) {
        return restaurantService.getAll(page, size);
    }

    @PostMapping("/order/calculate")
    public OrderPayload calculate(@RequestBody OrderPayload payload){
        return orderService.calculateNoAuth(payload);
    }


}
