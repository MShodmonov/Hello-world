package food.delivery.controller;


import food.delivery.entity.User;
import food.delivery.payloads.OrderPayload;
import food.delivery.security.CurrentUser;
import food.delivery.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/api/v1/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/calculate")
    public OrderPayload calculate(@RequestBody OrderPayload payload, @CurrentUser User user){
        return orderService.calculate(payload, user);
    }
}
