package food.delivery.controller;

import com.google.maps.errors.ApiException;
import food.delivery.entity.Address;
import food.delivery.entity.User;
import food.delivery.payloads.DiscountRestaurantPayload;
import food.delivery.payloads.RestaurantPayload;
import food.delivery.payloads.UserPayload;
import food.delivery.security.CurrentUser;
import food.delivery.service.AddressService;
import food.delivery.service.GoogleService;
import food.delivery.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import java.io.IOException;
import java.util.List;

@PreAuthorize("hasRole('OPERATOR') or hasRole('OWNER')")
@RestController
@RequestMapping(value = "/api/v1/restaurant")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    @Autowired
    private AddressService addressService;

    @PostMapping("/save/all")
    public void saveAll(@RequestBody List<List<RestaurantPayload>> list) {
        restaurantService.saveAll(list);
    }

    @PostMapping("/update/all")
    public void updateAll(@RequestBody List<List<RestaurantPayload>> list) {
        restaurantService.updateAll(list);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id) {
        restaurantService.delete(id);
    }

    @DeleteMapping("/delete/{restaurantId}/discount/{discountId}")
    public void deleteDiscountFromRestaurant(@PathVariable Long restaurantId, @PathVariable Long discountId) {
        restaurantService.deleteDiscountFromRestaurant(discountId, restaurantId);
    }

    @PostMapping("/discount/update")
    public void editDiscount(@RequestBody DiscountRestaurantPayload payload) {
        restaurantService.editDiscount(payload);
    }

    @GetMapping("/all")
    public Page<RestaurantPayload> getAll(@RequestParam Integer page, @RequestParam Integer size) {
        return restaurantService.getAll(page, size);
    }

    @GetMapping("/distance")
    public Page<RestaurantPayload> getAllWithDistance(@RequestParam Integer page, @RequestParam Integer size, @RequestParam Double longitude, @RequestParam Double latitude) throws IOException, InterruptedException, ApiException {
        return restaurantService.getAllWithDistance(page, size, longitude, latitude);
    }

    @GetMapping("/distance/secure")
    public Page<RestaurantPayload> getAllWithDistanceSecure(@RequestParam Integer page, @RequestParam Integer size, @CurrentUser User user) throws IOException, InterruptedException, ApiException {
        Address address = addressService.getDefaultAddress(user.getId());
        return restaurantService.getAllWithDistance(page, size, address.getLongitude(), address.getLatitude());
    }

    @GetMapping("/{id}")
    public List<RestaurantPayload> getWithId(@PathVariable Long id) {
        return restaurantService.getWithId(id);
    }

    @GetMapping("/update/manager")
    public void saveOrUpdate(@Valid @Pattern(regexp = "^\\d{12}$") @RequestParam String phoneNumber, @RequestParam Long restaurantId ){
        restaurantService.setManager(phoneNumber, restaurantId);
    }

    @GetMapping("/manager")
    public UserPayload getManager(@RequestParam Long restaurantId ){
        return restaurantService.getManager( restaurantId);
    }

}
