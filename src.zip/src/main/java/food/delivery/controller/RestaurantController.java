package food.delivery.controller;

import food.delivery.payloads.DiscountRestaurantPayload;
import food.delivery.payloads.RestaurantPayload;
import food.delivery.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/restaurant")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    @PostMapping("/save/all")
    public void saveAll(@RequestBody List<List<RestaurantPayload>> list) {
        restaurantService.saveAll(list);
    }

    @PostMapping("/update/all")
    public void updateAll(@RequestBody List<List<RestaurantPayload>> list) {
        restaurantService.updateAll(list);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        restaurantService.delete(id);
    }

    @DeleteMapping("/delete/{restaurantId}/discount/{discountId}")
    public void deleteDiscountFromRestaurant(@PathVariable Long restaurantId, @PathVariable Long discountId){
        restaurantService.deleteDiscountFromRestaurant(discountId, restaurantId);
    }

    @PostMapping("/discount/update")
    public void editDiscount(@RequestBody DiscountRestaurantPayload payload) {
        restaurantService.editDiscount(payload);
    }

    @GetMapping("/all")
    public Page<RestaurantPayload> getAll(@RequestParam Integer page, @RequestParam Integer size) {
        return restaurantService.getAll(page, size);
    }
}
