package food.delivery.controller;


import food.delivery.entity.eums.LanguageEnum;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1/main")
public class MainController {

    @GetMapping("/language")
    public LanguageEnum[] getLanguages(){
        return LanguageEnum.values();
    }
}
