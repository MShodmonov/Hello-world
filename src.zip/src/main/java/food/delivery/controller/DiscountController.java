package food.delivery.controller;


import food.delivery.payloads.DiscountPayload;
import food.delivery.service.DiscountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/discount")
public class DiscountController {

    @Autowired
    private DiscountService discountService;

    @PostMapping("/save")
    public void save(@RequestBody List<DiscountPayload> payloadList) {
        discountService.save(payloadList);
    }

    @PostMapping("/update")
    public void update(@RequestBody List<DiscountPayload> payloadList) {
        discountService.update(payloadList);
    }

    @GetMapping("/all")
    public Page<DiscountPayload> getAll(@RequestParam Integer page, @RequestParam Integer size) {
        return discountService.getAll(page, size);
    }

    @GetMapping("/restaurant/{restaurantId}")
    public List<DiscountPayload> getAllWithRestaurant(@PathVariable Long restaurantId){
        return discountService.getAllWithRestaurant(restaurantId);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        discountService.delete(id);
    }

    @GetMapping("/{id}")
    public List<DiscountPayload> getWithId(@PathVariable Long id){
        return discountService.getWithId(id);
    }




}
