package food.delivery.controller;


import food.delivery.payloads.FoodAdditionPayload;
import food.delivery.service.FoodAdditionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@PreAuthorize("hasRole('OPERATOR') or hasRole('OWNER')")
@RestController
@RequestMapping(value = "/api/v1/food-addition")
public class FoodAdditionController {

    @Autowired
    private FoodAdditionService foodAdditionService;


    @PostMapping("/save/all")
    public void save(@RequestBody List<List<FoodAdditionPayload>> list) {
        foodAdditionService.save(list);
    }

    @PostMapping("/update/all")
    public void update(@RequestBody List<List<FoodAdditionPayload>> list) {
        foodAdditionService.update(list);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        foodAdditionService.delete(id);
    }

    @GetMapping("/food/{foodId}")
    public List<FoodAdditionPayload> getAllWithFoodId(@PathVariable Long foodId){
        return foodAdditionService.getAllWithFoodId(foodId);
    }

    @GetMapping("/{id}")
    public List<FoodAdditionPayload> getWithId(@PathVariable Long id){
        return foodAdditionService.getWithId(id);
    }

}
