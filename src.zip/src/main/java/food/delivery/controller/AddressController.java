package food.delivery.controller;


import food.delivery.entity.User;
import food.delivery.payloads.AddressPayload;
import food.delivery.security.CurrentUser;
import food.delivery.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/address")
public class AddressController {

    @Autowired
    private AddressService addressService;


    @PostMapping("/save")
    public void save(@RequestBody AddressPayload payload, @CurrentUser User user){
        addressService.save(payload, user);
    }

    @PostMapping("/update")
    public void edit(@RequestBody AddressPayload payload, @CurrentUser User user){
        addressService.edit(payload, user);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id, @CurrentUser User user){
        addressService.delete(id, user);
    }

    @GetMapping("/current/{id}")
    public void makeCurrent(@PathVariable Long id, @CurrentUser User user){
        addressService.makeCurrent(id, user);
    }

    @GetMapping("/user")
    public List<AddressPayload> getUserAddress(@CurrentUser User user){
        return addressService.getAddresses(user);
    }

}
