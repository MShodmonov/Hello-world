package food.delivery.controller;


import food.delivery.service.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletRequest;
import java.util.UUID;


@PreAuthorize("hasRole('OPERATOR') or hasRole('OWNER')")
@RestController
@RequestMapping(value = "/api/v1/file")
public class FileController {

    @Autowired
    private FileStorageService storageService;

    @PostMapping("/")
    public String postFile(@RequestBody MultipartFile file) {
        return storageService.storeFile(file);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Resource> downloadFileById(@PathVariable UUID id, HttpServletRequest httpServletRequest) {
        return storageService.downloadFile(id.toString(), httpServletRequest);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable UUID id) {
        storageService.deleteFile(id.toString());
    }
}
