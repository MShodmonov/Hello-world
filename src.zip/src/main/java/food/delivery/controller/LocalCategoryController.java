package food.delivery.controller;

import food.delivery.payloads.LocalCategoryPayload;
import food.delivery.service.LocalCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/local-category")
public class LocalCategoryController {

    @Autowired
    private LocalCategoryService service;

    @PostMapping("/save")
    public void save(@RequestBody List<LocalCategoryPayload> list) {
        service.save(list);
    }

    @PostMapping("/update")
    public void update(@RequestBody List<LocalCategoryPayload> list) {
        service.update(list);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @GetMapping("/all")
    public Page<LocalCategoryPayload> getAll(@RequestParam Integer page, @RequestParam Integer size) {
        return service.getAll(page, size);
    }

    @GetMapping("/restaurant/{id}")
    public List<LocalCategoryPayload> getAllWithRestaurantId(@PathVariable Long id){
        return service.getAllWithRestaurantId(id);
    }




    }



