package food.delivery.payloads;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class DiscountRestaurantPayload {

    private Long discountId;

    private Long restaurantId;

    private List<Long> giftedFoodId;

    private List<Long> discountedFoodId;
}
