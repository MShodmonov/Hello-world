package food.delivery.payloads;

import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FoodPayloadAdmin {

    private Long id;

    private String imageUrl;

    private Long price;

    private String name;

    private LanguageEnum language;

    private Long localCategoryId;

    private String localCategoryName;

    private Long categoryId;

    private String categoryName;

    private String description;

    private Long preparationMinute;

    public FoodPayloadAdmin(Long id, String imageUrl, Long price, String name, LanguageEnum language, Long categoryId, String categoryName, String description, Long preparationMinute) {
        this.id = id;
        this.imageUrl = imageUrl;
        this.price = price;
        this.name = name;
        this.language = language;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.description = description;
        this.preparationMinute = preparationMinute;
    }
}
