package food.delivery.payloads;

import food.delivery.entity.OrderDiscount;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrderContentPayload {

    private Long id;

    private Long price;

    private Integer count;

    private String name;

    private Long foodAdditionId;

    private Long totalSum;
}
