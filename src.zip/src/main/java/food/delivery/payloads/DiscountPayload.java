package food.delivery.payloads;


import com.fasterxml.jackson.annotation.JsonFormat;
import food.delivery.entity.eums.DiscountEnum;
import food.delivery.entity.eums.DiscountReasonEnum;
import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DiscountPayload {

    private Long id;

    private String name;

    private String description;

    private LanguageEnum language;

    private Boolean active;

    private DiscountEnum discount;

    private DiscountReasonEnum discountReason;

    @JsonFormat(pattern = "yyyy/MM/dd HH:mm")
    private Date startTime;

    @JsonFormat(pattern = "yyyy/MM/dd HH:mm")
    private Date finishTime;

    private Long discountPercent;

    private Boolean freeDelivery;

    private Integer count;

    private Long minSum;

    private List<FoodPayload> discountedFood;

    private List<FoodPayload> giftFood;

    public DiscountPayload(Long id, String name, String description, LanguageEnum language, Boolean active, DiscountEnum discount, DiscountReasonEnum discountReason, Date startTime, Date finishTime, Long discountPercent, Boolean freeDelivery, Integer count, Long minSum) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.language = language;
        this.active = active;
        this.discount = discount;
        this.discountReason = discountReason;
        this.startTime = startTime;
        this.finishTime = finishTime;
        this.discountPercent = discountPercent;
        this.freeDelivery = freeDelivery;
        this.count = count;
        this.minSum = minSum;
    }
}
