package food.delivery.payloads;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SMSSendPayload {

    private String mobile_phone;

    private String message;

    private Integer from = 4546;

    private String callback_url = "http://0000.uz/test.php";

    public SMSSendPayload(String mobile_phone, String message) {
        this.mobile_phone = mobile_phone;
        this.message = message;
    }
}
