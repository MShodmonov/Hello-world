package food.delivery.payloads;

import food.delivery.entity.eums.OrderStatus;
import food.delivery.entity.eums.PaymentMethod;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrderPayload {

    private Long id;

    private Long restaurantId;

    private Long deliveryTime;

    private Long deliveryCost;

    private Long totalSum;

    private OrderStatus status;

    private Boolean isPickUp;

    private Boolean freeDelivery;

    private PaymentMethod paymentMethod;

    private List<OrderContentPayload> orderContentList;

    private List<OrderDiscountPayload> orderDiscountList;
}
