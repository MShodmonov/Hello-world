package food.delivery.payloads;


import food.delivery.entity.Discount;
import food.delivery.entity.OrderContent;
import food.delivery.entity.OrderDiscount;
import food.delivery.entity.eums.DiscountEnum;
import food.delivery.entity.eums.DiscountReasonEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrderDiscountPayload {

    private Long id;

    private String name;

    private DiscountEnum discount;

    private DiscountReasonEnum discountReason;

    private Long discountPercent;

    private Integer count;

    private Long minSum;

    private Long originalSum;

    private Long paidSum;
}
