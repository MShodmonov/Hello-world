package food.delivery.payloads;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
public class Message {

    private String event;
    private Object content;

    public Message() {
        super();
    }

}
