package food.delivery.payloads;


import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LocalCategoryPayload {

    private Long id;

    private String name;

    private LanguageEnum language;
}
