package food.delivery.payloads;

import food.delivery.utils.SMSUser;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SMSUserResponse {

    private String message;

    private SMSUser data;

}
