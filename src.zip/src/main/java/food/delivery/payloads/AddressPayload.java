package food.delivery.payloads;


import food.delivery.entity.eums.AddressTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AddressPayload {

    private Long id;

    private Double longitude;

    private Double latitude;

    private AddressTypeEnum addressTypeEnum;

    private String building;

    private Integer floor;

    private String house;

    private Boolean current;
}
