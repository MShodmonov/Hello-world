package food.delivery.payloads;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SMSLoginResponse {

    private String message;

    private Data data;

    public String getToken(){
        return this.data.getToken();
    }
}


