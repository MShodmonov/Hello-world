package food.delivery.payloads;

import food.delivery.entity.Role;
import food.delivery.entity.eums.RoleEnumeration;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserPayload {

    private Long id;

    private String username;

    private Boolean isEnabled;

    private Integer smsCount = 0;

    private String fullName;

    private Integer attemptCount = 0;

    private List<RoleEnumeration> roles;

    public UserPayload(Long id, String username, Boolean isEnabled, Integer smsCount, String fullName, Integer attemptCount) {
        this.id = id;
        this.username = username;
        this.isEnabled = isEnabled;
        this.smsCount = smsCount;
        this.fullName = fullName;
        this.attemptCount = attemptCount;
    }
}
