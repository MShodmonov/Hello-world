package food.delivery.payloads;


import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FoodAdditionPayload {

    private Long id;

    private Long price;

    private String name;

    private LanguageEnum language;

    private Long foodId;

    public FoodAdditionPayload(Long id, Long price, String name) {
        this.id = id;
        this.price = price;
        this.name = name;
    }

    public FoodAdditionPayload(Long id, Long price, String name, LanguageEnum language) {
        this.id = id;
        this.price = price;
        this.name = name;
        this.language = language;
    }
}
