package food.delivery.payloads;


import com.fasterxml.jackson.annotation.JsonFormat;
import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class RestaurantPayload {

    private Long id;

    private String imageUrl;

    private Double longitude;

    private Double latitude;

    private Boolean active;

    private String name;

    private Long commentCount;

    private Long totalScore;

    private Long totalOrders;

    private LanguageEnum language;

    private String description;

    @JsonFormat(pattern = "yyyy/MM/dd HH:mm")
    private Date openTime;

    @JsonFormat(pattern = "yyyy/MM/dd HH:mm")
    private Date closeTime;

    public RestaurantPayload(Long id, String imageUrl, Double longitude, Double latitude, Boolean active, String name, LanguageEnum language, Date openTime, Date closeTime) {
        this.id = id;
        this.imageUrl = imageUrl;
        this.longitude = longitude;
        this.latitude = latitude;
        this.active = active;
        this.name = name;
        this.language = language;
        this.openTime = openTime;
        this.closeTime = closeTime;
    }
}
