package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.translate.CategoryTranslate;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Category extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "category")
    private List<CategoryTranslate> categoryTranslates;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "category")
    private List<Food> foods;

    private String imageUrl;

    public Category(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
