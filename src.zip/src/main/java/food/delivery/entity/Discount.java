package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.DiscountEnum;
import food.delivery.entity.eums.DiscountReasonEnum;
import food.delivery.entity.translate.DiscountTranslate;
import lombok.*;
import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Discount extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "discount")
    private Set<DiscountTranslate> discountTranslates;

    private Boolean active;

    @Enumerated(EnumType.STRING)
    private DiscountEnum discount;

    @Enumerated(EnumType.STRING)
    private DiscountReasonEnum discountReason;

    @Temporal(TemporalType.TIMESTAMP)
    private Date startTime;

    @Temporal(TemporalType.TIMESTAMP)
    private Date finishTime;

    private Long discountPercent;

    private Boolean freeDelivery;

    private Integer count;

    private Long minSum;

    private Long maxSum = 0L;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToMany(mappedBy = "discounts")
    private Set<Restaurant> restaurants = new HashSet<>();

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToMany(mappedBy = "discounts")
    private Set<Food> discountedFood;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToMany(mappedBy = "giftDiscounts")
    private Set<Food> giftFoods;

    public Discount(Boolean active, DiscountEnum discount, DiscountReasonEnum discountReason, Date startTime, Date finishTime, Long discountPercent, Boolean freeDelivery, Integer count, Long minSum, Long maxSum) {
        this.active = active;
        this.discount = discount;
        this.discountReason = discountReason;
        this.startTime = startTime;
        this.finishTime = finishTime;
        this.discountPercent = discountPercent;
        this.freeDelivery = freeDelivery;
        this.count = count;
        this.minSum = minSum;
        this.maxSum = maxSum;
    }
}
