package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.translate.LocalCategoryTranslates;
import lombok.*;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LocalCategory extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "localCategory")
    private List<LocalCategoryTranslates> localCategoryTranslates;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "localCategory")
    private Set<Food> foods;
}
