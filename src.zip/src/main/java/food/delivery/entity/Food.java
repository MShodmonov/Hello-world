package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.translate.FoodTranslate;
import lombok.*;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Food extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "food")
    private List<FoodTranslate> foodTranslates;


    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "food")
    private Set<FoodAddition> foodAdditions;

    private String imageUrl;

    private Long price;

    private Long preparationMinute;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private Category category;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private LocalCategory localCategory;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private Restaurant restaurant;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToMany(cascade = CascadeType.MERGE)
    private Set<Discount> giftDiscounts;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToMany(cascade = CascadeType.MERGE)
    private Set<Discount> discounts;


    public Food(String imageUrl, Long price, Category category, LocalCategory localCategory, Restaurant restaurant, Long preparationMinute) {
        this.imageUrl = imageUrl;
        this.price = price;
        this.category = category;
        this.localCategory = localCategory;
        this.restaurant = restaurant;
        this.preparationMinute = preparationMinute;
    }
}
