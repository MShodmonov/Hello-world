package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.DiscountEnum;
import food.delivery.entity.eums.DiscountReasonEnum;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class OrderDiscount extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private OrderContent orderContent;

    private String name;

    @Enumerated(EnumType.STRING)
    private DiscountEnum discount;

    @Enumerated(EnumType.STRING)
    private DiscountReasonEnum discountReason;

    private Long discountPercent;

    private Integer count;

    private Long minSum;

    private Long originalSum;

    private Long paidSum;




}
