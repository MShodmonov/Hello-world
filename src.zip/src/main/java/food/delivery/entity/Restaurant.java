package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.translate.RestaurantTranslate;
import lombok.*;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Restaurant extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "restaurant")
    private List<RestaurantTranslate> translates;


    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "restaurant")
    private Set<Food> foods;

    private String imageUrl;

    private Double longitude;

    private Double latitude;

    private Boolean active;

    private Long commentCount = 0L;

    private Long totalScore = 0L;

    private Long totalOrders = 0L;

    @Temporal(TemporalType.TIMESTAMP)
    private Date openTime;

    @Temporal(TemporalType.TIMESTAMP)
    private Date closeTime;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToMany(cascade = CascadeType.MERGE)
    private Set<Discount> discounts;

    private Long managerId;



    public Restaurant( String imageUrl, Double longitude, Double latitude, Boolean active, Date openTime, Date closeTime) {
        this.imageUrl = imageUrl;
        this.longitude = longitude;
        this.latitude = latitude;
        this.active = active;
        this.openTime = openTime;
        this.closeTime = closeTime;
    }
}
