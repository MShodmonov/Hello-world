package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class OrderContent extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long price;

    private Integer count;

    private String name;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "orderContent")
    private Set<OrderDiscount> orderDiscounts;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private Order order;


}
