package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import lombok.*;

import javax.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Driver extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;

    private String phoneNumber;

    private String carModel;

    private String carNumber;

    private Long totalOrderCount;

    private Long driverUserId;

    private Boolean isEnabled = Boolean.TRUE;


}
