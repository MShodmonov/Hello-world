package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.AddressTypeEnum;
import lombok.*;

import javax.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Address extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private User user;

    private Double longitude;

    private Double latitude;

    @Enumerated(EnumType.STRING)
    private AddressTypeEnum addressTypeEnum;

    private String building;

    private Integer floor;

    private String house;

    private Boolean current = Boolean.FALSE;

    public Address(User user, Double longitude, Double latitude, AddressTypeEnum addressTypeEnum, String building, Integer floor, String house, Boolean current) {
        this.user = user;
        this.longitude = longitude;
        this.latitude = latitude;
        this.addressTypeEnum = addressTypeEnum;
        this.building = building;
        this.floor = floor;
        this.house = house;
        this.current = current;
    }
}
