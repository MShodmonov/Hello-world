package food.delivery.entity.translate;


import food.delivery.entity.Category;
import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.LanguageEnum;
import lombok.*;

import javax.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CategoryTranslate extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private Category category;

    @Column(unique = true)
    private String name;

    @Enumerated(EnumType.STRING)
    private LanguageEnum language;

    public CategoryTranslate(Category category, String name, LanguageEnum language) {
        this.category = category;
        this.name = name;
        this.language = language;
    }
}
