package food.delivery.entity.translate;


import food.delivery.entity.Discount;
import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.LanguageEnum;
import lombok.*;

import javax.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class DiscountTranslate extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String description;

    @Enumerated(EnumType.STRING)
    private LanguageEnum language;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private Discount discount;

    public DiscountTranslate(String name, String description, LanguageEnum language, Discount discount) {
        this.name = name;
        this.description = description;
        this.language = language;
        this.discount = discount;
    }
}