package food.delivery.entity.translate;

import food.delivery.entity.Restaurant;
import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.LanguageEnum;
import lombok.*;

import javax.persistence.*;
import java.io.StringReader;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RestaurantTranslate extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private Restaurant restaurant;

    private String name;

    private String description;

    @Enumerated(EnumType.STRING)
    private LanguageEnum language;

    public RestaurantTranslate(Restaurant restaurant, String name, LanguageEnum language, String description) {
        this.restaurant = restaurant;
        this.name = name;
        this.language = language;
        this.description = description;
    }
}
