package food.delivery.entity.eums;

public enum DiscountEnum {
    FREE_DELIVERY,
    PERCENT,
    ADDITIONAL_FOOD
}
