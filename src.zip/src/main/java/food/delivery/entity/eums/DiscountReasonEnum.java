package food.delivery.entity.eums;

public enum DiscountReasonEnum {
    TOTAL_SUM,
    FOOD,
    COUNT,
}
