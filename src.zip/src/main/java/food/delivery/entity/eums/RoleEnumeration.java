package food.delivery.entity.eums;

public enum RoleEnumeration {
    ROLE_OWNER,
    ROLE_OPERATOR,
    ROLE_RESTAURANT,
    ROLE_DRIVER,
    ROLE_USER,
}