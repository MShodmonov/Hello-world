package food.delivery.entity.eums;

public enum PaymentMethod {
    CASH,
    ONLINE,
    CARD,
}
