package food.delivery.entity.eums;

public enum OrderStatus {
    CREATED,
    ACCEPTED,
    REJECTED,
    PREPARING,
    READY_TO_DELIVER,
    ON_THE_WAY,
    DELIVERED,
    READY_TO_PICK_UP,
    CLIENT_FAILED,
    TAXI_FAILED,
}
