package food.delivery.entity.eums;

public enum LanguageEnum {
    uz,
    ru
}
