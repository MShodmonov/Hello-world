package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.OrderStatus;
import food.delivery.entity.eums.PaymentMethod;
import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "orders")
public class Order extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long restaurantId;

    private Long deliveryTime;

    private Long deliveryCost;

    private Long totalSumContent;

    private Long sum;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    private Boolean isPickUp;

    private Boolean freeDelivery;

    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod;


    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "order")
    private Set<OrderContent> orderContents;


    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private User client;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private User driver;

    private Boolean isRestaurantPaid = Boolean.FALSE;

    private Boolean isDriverPaid = Boolean.FALSE;

}
