package food.delivery.utils;

public class DefaultData {

    private String userId;
    private String username;
    private String tokenId;
    private String currentLang;

    public DefaultData() {
        super();
    }

    public DefaultData(String currentLang) {
        this.currentLang = currentLang;
    }

    public DefaultData(String userId, String username, String tokenId) {
        this.userId = userId;
        this.username = username;
        this.tokenId = tokenId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getCurrentLang() {
        return currentLang;
    }

    public void setCurrentLang(String currentLang) {
        this.currentLang = currentLang;
    }
}