package food.delivery.utils;


import food.delivery.entity.User;
import food.delivery.entity.eums.LanguageEnum;

public class UserSettings {

    private static LanguageEnum language = LanguageEnum.uz;

    public static LanguageEnum getLanguage() {
        return language;
    }

    public static void setLanguage(LanguageEnum language) {
        UserSettings.language = language;
    }
}
