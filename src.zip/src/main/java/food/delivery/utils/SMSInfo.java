package food.delivery.utils;

public class SMSInfo {

    private static String token;

    private static SMSUser user;

    private static SMSStatus status;

    public static String getToken() {
        return token;
    }

    public static void setToken(String token) {
        SMSInfo.token = token;
    }

    public static SMSUser getUser() {
        return user;
    }

    public static void setUser(SMSUser user) {
        SMSInfo.user = user;
    }

    public static SMSStatus getStatus() {
        return status;
    }

    public static void setStatus(SMSStatus status) {
        SMSInfo.status = status;
    }
}
