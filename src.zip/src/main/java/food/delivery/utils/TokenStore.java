package food.delivery.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TokenStore {

    private static List<TokenInfo> tokensList = new ArrayList<>();

    public static void add(TokenInfo tokenInfo) {
        if (tokenInfo != null) {
            tokensList.add(tokenInfo);
        }
    }

    public static void remove(TokenInfo tokenInfo) {
        if (tokenInfo != null) {
            tokensList.remove(tokenInfo);
        }
    }

    public static TokenInfo findByTokenId(String tokenId) {
        return tokensList.stream()
                .filter(t -> t.getTokenId().equals(tokenId))
                .findFirst().orElse(null);
    }

    public static boolean tokenExists(String token) {
        return tokensList.stream()
                .filter(t -> t.getAccessToken().equals(token) || t.getRefreshToken().equals(token))
                .count() == 1;
    }

    public static long countTokens() {
        return tokensList.size();
    }

    public static void removeInvalidTokens() {

        if (countTokens() > 100) {
            tokensList.stream().filter(t -> new Date().getTime() - t.getAccessTokenExpiresIn() > 86400000)
                    .forEach(TokenStore::remove);
        }
    }


}