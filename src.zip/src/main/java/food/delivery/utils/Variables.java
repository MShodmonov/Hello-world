package food.delivery.utils;

import food.delivery.entity.ProjectConstants;

public class Variables {

    private static ProjectConstants constants;

    public static ProjectConstants getConstants() {
        return constants;
    }

    public static void setConstants(ProjectConstants constants) {
        Variables.constants = constants;
    }
}
