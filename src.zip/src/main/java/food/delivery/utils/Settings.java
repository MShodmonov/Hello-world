package food.delivery.utils;

public class Settings {

    private static DefaultData defaultData;

    public static DefaultData getDefaultData() {
        return defaultData;
    }

    public static void setDefaultData(DefaultData defaultData) {
        Settings.defaultData = defaultData;
    }
}