package food.delivery.repository;

import food.delivery.entity.Food;
import food.delivery.entity.eums.LanguageEnum;
import food.delivery.payloads.FoodPayload;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FoodRepo extends JpaRepository<Food, Long> {

    @Query("select new food.delivery.payloads.FoodPayload(f.id, f.imageUrl, f.price, ft.name ,ft.language, f.preparationMinute ) from Food f join f.foodTranslates ft join f.discounts d where ft.language=?1 and d.id=?2 and f.restaurant.id=?3")
    List<FoodPayload> findDiscountedFoodWithDiscountId(LanguageEnum languageEnum, Long discountId, Long restaurantId);

    @Query("select new food.delivery.payloads.FoodPayload(f.id, f.imageUrl, f.price, ft.name ,ft.language, f.preparationMinute ) from Food f join f.foodTranslates ft join f.giftDiscounts d where ft.language=?1 and d.id=?2 and f.restaurant.id=?3")
    List<FoodPayload> findGiftedFoodWithDiscountId(LanguageEnum languageEnum, Long discountId, Long restaurantId);


    @Query("select f from Food f join f.discounts d where d.id=?1 and f.restaurant.id=?2")
    List<Food> findDiscountedFoodWithDiscountIdEntity(Long discountId, Long restaurantId);

    @Query("select f from Food f join f.giftDiscounts d where d.id=?1 and f.restaurant.id=?2")
    List<Food> findGiftedFoodWithDiscountIdEntity(Long discountId, Long restaurantId);

    @Query("select f from Food f join f.discounts d where d.id=?1")
    List<Food> findDiscountedFoodWithOnlyDiscountIdEntity(Long discountId);

    @Query("select f from Food f join f.giftDiscounts d where d.id=?1")
    List<Food> findGiftedFoodWithOnlyDiscountIdEntity(Long discountId);

    @Query("select f from Food f where f.id in :idList")
    List<Food> findAllWithId(@Param("idList") List<Long> idList);

}


