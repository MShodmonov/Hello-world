package food.delivery.repository.translate;

import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.translate.DiscountTranslate;
import food.delivery.payloads.DiscountPayload;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface DiscountTranslateRepo extends JpaRepository<DiscountTranslate, Long> {

    Optional<DiscountTranslate> findByLanguageAndDiscount_Id(LanguageEnum languageEnum, Long discountId);

    @Query("select new food.delivery.payloads.DiscountPayload(d.id, dt.name, dt.description, dt.language, d.active, d.discount, d.discountReason, d.startTime, d.finishTime, d.discountPercent, d.freeDelivery, d.count, d.minSum) from Discount d join d.discountTranslates dt where dt.language=?1 order by d.createdAt desc")
    Page<DiscountPayload> findAllWithLanguage(Pageable pageable, LanguageEnum languageEnum);

    @Query("select new food.delivery.payloads.DiscountPayload(d.id, dt.name, dt.description, dt.language, d.active, d.discount, d.discountReason, d.startTime, d.finishTime, d.discountPercent, d.freeDelivery, d.count, d.minSum) from Discount d join d.discountTranslates dt where d.id=?1 order by d.createdAt desc")
    List<DiscountPayload> findWithId(Long id);

    @Query("select new food.delivery.payloads.DiscountPayload(d.id, dt.name, dt.description, dt.language, d.active, d.discount, d.discountReason, d.startTime, d.finishTime, d.discountPercent, d.freeDelivery, d.count, d.minSum) from Discount d join d.discountTranslates dt join d.restaurants r where dt.language=?1 and r.id= ?2 order by d.createdAt desc")
    List<DiscountPayload> findAllForRestaurant(LanguageEnum languageEnum, Long restaurantId);

    List<DiscountTranslate> findAllByDiscount_Id(Long discountId);
}
