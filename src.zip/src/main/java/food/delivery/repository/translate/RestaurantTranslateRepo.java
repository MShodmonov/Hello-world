package food.delivery.repository.translate;

import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.translate.RestaurantTranslate;
import food.delivery.payloads.RestaurantPayload;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface RestaurantTranslateRepo extends JpaRepository<RestaurantTranslate, Long> {

    @Query("select new food.delivery.payloads.RestaurantPayload(r.id, r.imageUrl, r.longitude, r.latitude, r.active, rt.name, rt.language, r.openTime, r.closeTime) from Restaurant r join r.translates rt where rt.language=?1 order by rt.name asc")
    Page<RestaurantPayload> getAllRestaurantsWithLanguage(Pageable pageable, LanguageEnum languageEnum);

    Optional<RestaurantTranslate> findByLanguageAndRestaurant_Id(LanguageEnum languageEnum, Long restaurantId);

    List<RestaurantTranslate> findAllByRestaurant_Id(Long restaurantId);
}
