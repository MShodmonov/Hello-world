package food.delivery.repository;


import food.delivery.entity.Role;
import food.delivery.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    @Query("select u.roles from users u where u.id=?1")
    List<Role> getAllRolesWithUserId(Long userID);

}
