package food.delivery.repository;


import food.delivery.entity.User;
import food.delivery.payloads.UserPayload;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    @Query("select new food.delivery.payloads.UserPayload(u.id, u.username, u.isEnabled, u.smsCount, u.fullName, u.attemptCount) from users u where u.restaurantId=?1")
    Optional<UserPayload> findWithRestaurantId(Long restaurantId);

}
