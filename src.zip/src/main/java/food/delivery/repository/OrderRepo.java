package food.delivery.repository;

import food.delivery.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepo extends JpaRepository<Order, Long> {

    Integer countByClient_IdAndRestaurantId(Long clientId, Long restaurantId);
}
