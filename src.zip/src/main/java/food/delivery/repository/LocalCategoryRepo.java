package food.delivery.repository;

import food.delivery.entity.LocalCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalCategoryRepo  extends JpaRepository<LocalCategory, Long> {
}
