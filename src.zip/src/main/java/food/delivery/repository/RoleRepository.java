package food.delivery.repository;


import food.delivery.entity.Role;
import food.delivery.entity.eums.RoleEnumeration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Role findByName(RoleEnumeration roleEnumeration);
}