package food.delivery.repository;


import food.delivery.entity.Role;
import food.delivery.entity.eums.RoleEnumeration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Role findByName(RoleEnumeration roleEnumeration);

    @Query("select r.name from roles r join r.users u where u.id=?1")
    List<RoleEnumeration> getUserRoles(Long userId);

}