package food.delivery.repository;

import food.delivery.entity.OrderContent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderContentRepo extends JpaRepository<OrderContent, Long> {
}
