package food.delivery.repository;

import food.delivery.entity.Discount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Set;

public interface DiscountRepo extends JpaRepository<Discount, Long> {

    @Query("select d from Discount d join d.discountedFood f where f.id=?1")
    List<Discount> findAllWithDiscountedFoodId(Long discount);

    @Query("select d from Discount d join d.giftFoods f where f.id=?1")
    List<Discount> findGiftDiscountWithDiscountedFoodId(Long food);


    @Query("select d from Discount d join d.restaurants r where r.id=?1")
    Set<Discount> findAllWithRestaurantId(Long restaurantId);
}
