package food.delivery.repository;

import food.delivery.entity.Address;
import food.delivery.entity.User;
import food.delivery.payloads.AddressPayload;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

public interface AddressRepo extends JpaRepository<Address, Long> {

    List<Address> findAllByUser_IdAndCurrent(Long userId, Boolean current);

    Boolean existsAddressByIdAndUser_Id(Long id, Long userId);

    @Query("select new food.delivery.payloads.AddressPayload(a.id, a.longitude, a.latitude, a.addressTypeEnum, a.building, a.floor, a.house, a.current) from Address a where a.user.id=?1")
    List<AddressPayload> findAllWithUserId(Long userId);

    Optional<Address> findByUser_IdAndCurrent(Long userId, Boolean current);
}
