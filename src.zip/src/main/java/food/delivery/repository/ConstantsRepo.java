package food.delivery.repository;

import food.delivery.entity.ProjectConstants;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConstantsRepo extends JpaRepository<ProjectConstants, Long> {
}
