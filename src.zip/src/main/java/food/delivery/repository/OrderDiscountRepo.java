package food.delivery.repository;

import food.delivery.entity.OrderDiscount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderDiscountRepo  extends JpaRepository<OrderDiscount, Long> {
}
