package food.delivery.repository;

import food.delivery.entity.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Set;

public interface RestaurantRepo extends JpaRepository<Restaurant, Long> {

    @Query("select r from Restaurant r join r.discounts d where d.id=?1")
    List<Restaurant> findAllWithDiscountId(Long discountId);
}
