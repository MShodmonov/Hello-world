package food.delivery.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import food.delivery.entity.eums.LanguageEnum;
import food.delivery.utils.DefaultData;
import food.delivery.utils.Settings;
import food.delivery.utils.TokenStore;
import food.delivery.utils.UserSettings;
import io.jsonwebtoken.JwtException;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

public class JwtTokenFilter extends GenericFilterBean {

    private JwtTokenProvider jwtTokenProvider;

    JwtTokenFilter(JwtTokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws ServletException {

        try {

            final String SIGN_IN = "/api/v1/auth/signin";
            final String MAIN_URL = "/api/v1/main/";
            final String SIGN_UP = "/api/v1/auth/save/user";
            final String CHECK = "/api/v1/auth/check";
            final String ACTIVATE = "/api/v1/auth/activate";
            final String RESTORE = "/api/v1/auth/restore";
            final String WEB = "/api/v1/web/";


            HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;


            if (!(httpServletRequest.getRequestURI().equalsIgnoreCase(SIGN_IN) || httpServletRequest.getRequestURI().startsWith(MAIN_URL)
                    || httpServletRequest.getRequestURI().equalsIgnoreCase(SIGN_UP)
                    || httpServletRequest.getRequestURI().equalsIgnoreCase(CHECK)
                    || httpServletRequest.getRequestURI().equalsIgnoreCase(ACTIVATE)
                    || httpServletRequest.getRequestURI().equalsIgnoreCase(RESTORE)
                    || httpServletRequest.getRequestURI().startsWith(WEB)

            )) {

                String token = jwtTokenProvider.resolveToken(httpServletRequest);

                if (token == null) {
                    sendErrorResponse(HttpStatus.UNAUTHORIZED, "Token not found",
                            servletResponse);
                    return;
                }

                if (!TokenStore.tokenExists(token)) {
                    sendErrorResponse(HttpStatus.UNAUTHORIZED, "Token expired or deleted",
                            servletResponse);
                    return;
                }

                if (jwtTokenProvider.validateToken(token)) {
                    Authentication authentication = jwtTokenProvider.getAuthentication(token);

                    if (authentication != null) {

                        SecurityContextHolder.getContext().setAuthentication(authentication);
                        DefaultData defaultData = jwtTokenProvider.getDefaultDataFromToken(token);
                        Settings.setDefaultData(defaultData);
                    } else{
                        sendErrorResponse(HttpStatus.UNAUTHORIZED, "Authentication failed",
                                servletResponse);
                        return;
                    }
                }
            }
            UserSettings.setLanguage(getUserCurrentLanguage(httpServletRequest));
            filterChain.doFilter(servletRequest, servletResponse);

        } catch (JwtException | IllegalArgumentException | IOException ex) {
            sendErrorResponse(HttpStatus.UNAUTHORIZED, "JWT token is expired or invalid",
                    servletResponse);
        }
    }

    private LanguageEnum getUserCurrentLanguage(HttpServletRequest request) {
        String language = request.getHeader("Language");
        if (StringUtils.hasText(language)) {
            for (LanguageEnum languageEnum : LanguageEnum.values()) {
                if (languageEnum.toString().equals(language)) {
                    return languageEnum;
                }
            }
        }
        return LanguageEnum.uz;
    }

    private void sendErrorResponse(HttpStatus status, String message, ServletResponse servletResponse) {
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        response.setStatus(status.value());
        response.setContentType("application/json");

        try {

            HashMap<String, Object> res = new HashMap<>();
            res.put("error", status.value());
            res.put("message", message);

            response.getWriter().write(new ObjectMapper().writeValueAsString(res));
            response.getWriter().flush();
            response.getWriter().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
