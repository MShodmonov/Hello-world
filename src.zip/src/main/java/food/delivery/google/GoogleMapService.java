package food.delivery.google;

import com.google.maps.GeoApiContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class GoogleMapService {

    private final RestTemplate restTemplate;

    public final GeoApiContext context;

    private Map<String, String> params = null;

//    @Value("${google.api.key}")
    private String secretKey = "AIzaSyCYwhz35fl7md7TI4KYewAGwh2U6Z8lk7E";

    @Autowired
    public GoogleMapService() {
        restTemplate = new RestTemplate();
        context = new GeoApiContext.Builder()
                .apiKey(secretKey)
                .queryRateLimit(30)
                .build();
    }
}
