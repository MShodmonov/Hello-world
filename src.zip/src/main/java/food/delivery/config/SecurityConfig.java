package food.delivery.config;

import food.delivery.security.JwtAuthenticationEntryPoint;
import food.delivery.security.JwtConfigurer;
import food.delivery.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(
        prePostEnabled = true,
        securedEnabled = true,
        jsr250Enabled = true,
        proxyTargetClass = true
)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private static final String SIGN_IN = "/api/v1/auth/signin";
    private static final String SIGN_UP = "/api/v1/auth/save/user";
    private static final String CHECK = "/api/v1/auth/check";
    private static final String ACTIVATE = "/api/v1/auth/activate";
    private static final String MAIN_URL = "/api/v1/main/**";
    private static final String RESTORE = "/api/v1/auth/restore";
    private static final String WEB = "/api/v1/web/**";

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .cors().and()
                .csrf().disable()
                .exceptionHandling()
                .authenticationEntryPoint(jwtAuthenticationEntryPoint)
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .apply(new JwtConfigurer(jwtTokenProvider))
                .and()
                .authorizeRequests()
                .antMatchers(SIGN_IN).permitAll()
                .antMatchers(MAIN_URL).permitAll()
                .antMatchers(SIGN_UP).permitAll()
                .antMatchers(CHECK).permitAll()
                .antMatchers(ACTIVATE).permitAll()
                .antMatchers(RESTORE).permitAll()
                .antMatchers(WEB).permitAll()
                .antMatchers("/mb-websocket/**").permitAll()
                .anyRequest().authenticated();
    }
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/v3/api-docs/**", "/swagger-ui.html", "/swagger-ui/**");
    }
}
