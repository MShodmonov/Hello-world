package food.delivery.bootstrap;


import food.delivery.entity.ProjectConstants;
import food.delivery.entity.Role;
import food.delivery.entity.User;
import food.delivery.entity.eums.RoleEnumeration;
import food.delivery.repository.ConstantsRepo;
import food.delivery.repository.RoleRepository;
import food.delivery.repository.UserRepository;
import food.delivery.service.ConstantsService;
import food.delivery.service.SMSService;
import food.delivery.utils.SMSInfo;
import food.delivery.utils.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Dataloader implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private ConstantsRepo constantsRepo;

    @Autowired
    private SMSService smsService;

    @Autowired
    private ConstantsService constantsService;


    @Override
    public void run(String... args) throws Exception {

        Variables.setConstants(constantsService.get());


        if (roleRepository.count() == 0) {
            roleRepository.save(new Role(RoleEnumeration.ROLE_USER));
            roleRepository.save(new Role(RoleEnumeration.ROLE_DRIVER));
            roleRepository.save(new Role(RoleEnumeration.ROLE_OPERATOR));
            roleRepository.save(new Role(RoleEnumeration.ROLE_OWNER));
            roleRepository.save(new Role(RoleEnumeration.ROLE_RESTAURANT));
        }

        if (userRepository.findByUsername("998934364236").isEmpty()) {
            userRepository.save(new User("998934364236", passwordEncoder.encode("12345"), Boolean.TRUE, List.of(roleRepository.findByName(RoleEnumeration.ROLE_OWNER))));
        }

        if (userRepository.findByUsername("998934364237").isEmpty()) {
            userRepository.save(new User("998934364237", passwordEncoder.encode("12345"), Boolean.TRUE, List.of(roleRepository.findByName(RoleEnumeration.ROLE_OPERATOR))));
        }
        if (constantsRepo.count() == 0) {
            constantsRepo.save(new ProjectConstants(1200L));
        }

//        smsService.getUserInfoAndToken();
//        System.out.println(SMSInfo.getStatus());


    }
}
