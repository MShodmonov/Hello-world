package food.delivery.service;


import food.delivery.entity.User;
import food.delivery.exceptions.BadRequestException;
import food.delivery.payloads.SMSLoginResponse;
import food.delivery.payloads.SMSSendPayload;
import food.delivery.payloads.SMSSigninRequest;
import food.delivery.payloads.SMSUserResponse;
import food.delivery.repository.UserRepository;
import food.delivery.utils.JsonRestTemplate;
import food.delivery.utils.LoggingRequestInterceptor;
import food.delivery.utils.SMSInfo;
import food.delivery.utils.SMSStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SMSService {

    @Value("${eskiz.login.url}")
    private String loginUrl;

    @Value("${eskiz.refresh.url}")
    private String refreshUrl;

    @Value("${eskiz.email}")
    private String email;

    @Value("${eskiz.password}")
    private String password;

    @Value("${eskiz.info.url}")
    private String infoUrl;

    @Value("${eskiz.send.url}")
    private String sendUrl;

    @Value("${sms.count}")
    private Integer smsCount;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;



    private RestTemplate restTemplate;

    @Autowired
    private UserRepository userRepository;

    @PostConstruct
    public void createRestTemplate() {
//        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("172.16.0.113", 3128));
//        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
//
//        SimpleClientHttpRequestFactory noRedirectRequestFactory = new SimpleClientHttpRequestFactory() {
//            @Override
//            protected void prepareConnection(HttpURLConnection connection, String httpMethod) {
//                connection.setInstanceFollowRedirects(true);
//            }
//        };
//        noRedirectRequestFactory.setProxy(proxy);
//        requestFactory.setProxy(proxy);
//        restTemplate = new JsonRestTemplate(new BufferingClientHttpRequestFactory(requestFactory));
//        List<ClientHttpRequestInterceptor> interceptors = new LinkedList<>();
//        interceptors.add(new LoggingRequestInterceptor());
//        //      restTemplate.setInterceptors(interceptors);
    }


    public void getUserInfoAndToken() {
        getToken();
        getUserInfo();
        SMSInfo.setStatus(SMSStatus.WORKING);
    }

    public void getToken() {
        HttpEntity<SMSSigninRequest> object = new HttpEntity<>(new SMSSigninRequest(email, password));
        ResponseEntity<SMSLoginResponse> responseEntity = restTemplate.postForEntity(loginUrl, object, SMSLoginResponse.class);
        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            SMSInfo.setToken(responseEntity.getBody().getToken());
        } else SMSInfo.setStatus(SMSStatus.NOT_WORKING);
    }

    public void getUserInfo() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(SMSInfo.getToken());
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<SMSUserResponse> response = restTemplate.exchange(infoUrl, HttpMethod.GET, entity, SMSUserResponse.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            SMSInfo.setUser(response.getBody().getData());
        } else SMSInfo.setStatus(SMSStatus.NOT_WORKING);

    }

    @Transactional
    public void sendMessage(String phoneNumber) {
        try {
            if (!SMSInfo.getToken().isEmpty()) {
                User user = userRepository.findByUsername(phoneNumber).orElseThrow(() -> new BadRequestException("user with " + phoneNumber + " has not been found"));
                if (user.getSmsCount() < smsCount && !(user.isEnabled()) && user.getUsername().equals(phoneNumber)) {
                    user.setSmsCount(user.getSmsCount() + 1);
                    SecureRandom random = new SecureRandom();
                    Integer num = random.nextInt(100000);
                    String formatted = String.format("%05d", num);
                    user.setPassword(passwordEncoder.encode(formatted));
                    HttpHeaders headers = new HttpHeaders();
                    headers.setBearerAuth(SMSInfo.getToken());
                    HttpEntity<SMSSendPayload> entity = new HttpEntity<>(new SMSSendPayload(phoneNumber, "your MedPay verification code is " + formatted), headers);
                    restTemplate.exchange(sendUrl, HttpMethod.POST, entity, Object.class);
                    userRepository.save(user);
                } else throw new BadRequestException("your sms limit has reached");
            } else SMSInfo.setStatus(SMSStatus.NOT_WORKING);
        } catch (Exception e) {
            throw new BadRequestException("you have send your phone number wrong");
        }
    }

    @Scheduled(cron = "* 30 1 1,15 * *")
    public void scheduleTaskUsingCronExpression() {
        getToken();
        userRepository.saveAll(userRepository.findAll().stream().peek(user ->
        {
            user.setSmsCount(0);
            user.setAttemptCount(0);
        }
        ).collect(Collectors.toList()));

    }

}