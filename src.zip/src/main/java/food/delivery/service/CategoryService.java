package food.delivery.service;


import food.delivery.entity.Category;
import food.delivery.entity.translate.CategoryTranslate;
import food.delivery.exceptions.ResourceNotFoundException;
import food.delivery.payloads.CategoryPayload;
import food.delivery.repository.CategoryRepo;
import food.delivery.repository.translate.CategoryTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private CategoryTranslateRepo categoryTranslateRepo;

    @Transactional
    public void saveAll(List<List<CategoryPayload>> list){
        list.forEach(payloadList -> {
            Category category = categoryRepo.save(new Category(payloadList.get(0).getImageUrl()));
            payloadList.forEach(payload -> {
                categoryTranslateRepo.save(new CategoryTranslate(category, payload.getName(), payload.getLanguage()));
            });
        });
    }

    public Page<CategoryPayload> getAll(Integer page, Integer size){
        return categoryTranslateRepo.getAllCategoriesWithLanguage(PageRequest.of(page, size), UserSettings.getLanguage());
    }

    @Transactional
    public void updateAll(List<List<CategoryPayload>> list){
        list.forEach(payloadList -> {
            Category category = categoryRepo.findById(payloadList.get(0).getId()).orElseThrow(() -> new ResourceNotFoundException("category with id does not exist: " + payloadList.get(0).getId()));
            payloadList.forEach(payload -> {
                CategoryTranslate categoryTranslate = categoryTranslateRepo.findByLanguageAndCategory_Id(payload.getLanguage(), payload.getId()).orElse(new CategoryTranslate(category, payload.getName(), payload.getLanguage()));
                categoryTranslate.setName(payload.getName());
                categoryTranslateRepo.save(categoryTranslate);

            });
        });
    }

    @Transactional
    public void delete(Long id){
        Category category = categoryRepo.getById(id);
        categoryTranslateRepo.deleteAll(categoryTranslateRepo.findByCategory_Id(id));
        categoryRepo.delete(category);
    }

    public List<CategoryPayload> getById(Long id){
        return categoryTranslateRepo.getAllCategoryWithId(id);
    }

}
