package food.delivery.service;


import food.delivery.config.FileStorageProperties;
import food.delivery.exceptions.FileStorageException;
import food.delivery.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileStorageService {

    private final Path fileStorageLocation;

    @Autowired
    public FileStorageService(FileStorageProperties fileStorageLocation) {
        this.fileStorageLocation = Paths.get(fileStorageLocation.getUploadDir()).toAbsolutePath().normalize();
        try {
            if (!Files.exists(this.fileStorageLocation))
                Files.createDirectory(this.fileStorageLocation);
        } catch (IOException e) {
            throw new FileStorageException("Could not create the directory where the uploaded files will be stored.", e);
        }
    }

    public String storeFile(MultipartFile multipartFile) {
            String fileName = StringUtils.cleanPath(UUID.randomUUID().toString());
            try {
                Path targetLocation = this.fileStorageLocation.resolve(fileName);
                Files.copy(multipartFile.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
                return  fileName;
            } catch (IOException e) {
                throw new FileStorageException("Could not store file " + fileName + ". Please try again!", e);
            }

    }

    public Resource loadFileAsResource(String fileName) {
        try {
            Path filePath = this.fileStorageLocation.resolve(fileName);
            UrlResource urlResource = new UrlResource(filePath.toUri());
            if (urlResource.exists()) {
                return urlResource;
            } else throw new ResourceNotFoundException("File not found " + fileName);
        } catch (MalformedURLException e) {
            throw new ResourceNotFoundException("File not found " + fileName, e);
        }
    }
    public ResponseEntity<Resource> downloadFile(String filename, HttpServletRequest request) {
        Resource resource = loadFileAsResource(filename);

        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        try {
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .contentLength(resource.contentLength())
                    .body(resource);
        } catch (IOException e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("not found");
        }

    }



    public Boolean deleteFile(String name) {
        try {
            Path filePath = this.fileStorageLocation.resolve(name);
            File file = new File(filePath.toUri());
            return file.delete();
        } catch (Exception e) {
            throw new ResourceNotFoundException("File not found " + name, e);
        }
    }

}
