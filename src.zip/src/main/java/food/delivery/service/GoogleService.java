package food.delivery.service;


import com.google.maps.DistanceMatrixApi;
import com.google.maps.errors.ApiException;
import com.google.maps.model.*;
import food.delivery.exceptions.BadRequestException;
import food.delivery.google.GoogleMapService;
import food.delivery.payloads.RestaurantPayload;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
public class GoogleService {

    @Autowired
    private GoogleMapService googleMapService;

    public void testDistance() throws InterruptedException, ApiException, IOException {
        DistanceMatrix distanceMatrix = DistanceMatrixApi.newRequest(googleMapService.context)
                .origins(new LatLng(40.08323345686939, 65.36415819642457))
                .destinations(new LatLng(40.111665562284784, 65.3464130319624), new LatLng(40.086198329874975, 65.33666514676997))
                .mode(TravelMode.DRIVING)
                .await();
        for (DistanceMatrixRow row : distanceMatrix.rows) {
            for (DistanceMatrixElement element : row.elements) {
                System.out.println(element);
            }
        }
    }

    public List<RestaurantPayload> calculateDistance(List<RestaurantPayload> payloadList, LatLng position) {
        try {
            DistanceMatrix distanceMatrix = DistanceMatrixApi.newRequest(googleMapService.context)
                    .origins(position)
                    .destinations(payloadList.stream().map(payload -> new LatLng(payload.getLatitude(), payload.getLongitude())).toArray(LatLng[]::new))
                    .mode(TravelMode.DRIVING)
                    .await();

            DistanceMatrixElement[] elements = distanceMatrix.rows[0].elements;
            for (int i = 0; i < elements.length; i++) {
                payloadList.get(i).setDrivingTime(elements[i].duration.inSeconds / 60);
                payloadList.get(i).setDrivingLength(BigDecimal.valueOf(elements[i].distance.inMeters).divide(BigDecimal.valueOf(1000)));
            }
            return payloadList;
        } catch (Exception e) {
            throw new BadRequestException("Error with message: " + e.getMessage());
        }

    }

    public DistanceMatrixElement calculateRoute(LatLng origin, LatLng destination){
        try {
            DistanceMatrix distanceMatrix = DistanceMatrixApi.newRequest(googleMapService.context)
                    .origins(origin)
                    .destinations(destination)
                    .mode(TravelMode.DRIVING)
                    .await();
           return distanceMatrix.rows[0].elements[0];
        }catch (Exception e){
            throw new BadRequestException("Google server is not working:" + e.getMessage());
        }

    }
}
