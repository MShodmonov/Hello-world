package food.delivery.service;


import com.google.maps.DistanceMatrixApi;
import com.google.maps.errors.ApiException;
import com.google.maps.model.*;
import food.delivery.google.GoogleMapService;
import food.delivery.payloads.RestaurantPayload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
public class GoogleService {

    @Autowired
    private GoogleMapService googleMapService;

    public void testDistance() throws InterruptedException, ApiException, IOException {
        DistanceMatrix distanceMatrix = DistanceMatrixApi.newRequest(googleMapService.context)
                .origins(new LatLng(40.08323345686939, 65.36415819642457))
                .destinations(new LatLng(40.111665562284784, 65.3464130319624 ), new LatLng( 40.086198329874975, 65.33666514676997))
                .mode(TravelMode.DRIVING)
                .await();
        for (DistanceMatrixRow row : distanceMatrix.rows){
         for (DistanceMatrixElement element : row.elements){
             System.out.println(element);
         }
        }
    }

    public void calculateDistance(List<RestaurantPayload> payloadList, LatLng position) throws InterruptedException, ApiException, IOException {
        LatLng[] array = (LatLng[]) payloadList.stream().map(payload -> new LatLng(payload.getLatitude(), payload.getLongitude())).toArray();
        DistanceMatrix distanceMatrix = DistanceMatrixApi.newRequest(googleMapService.context)
                .origins(position)
                .destinations(array)
                .mode(TravelMode.DRIVING)
                .await();

    }
}
