package food.delivery.service;


import food.delivery.entity.Food;
import food.delivery.entity.FoodAddition;
import food.delivery.entity.translate.FoodAdditionTranslate;
import food.delivery.exceptions.ResourceNotFoundException;
import food.delivery.payloads.FoodAdditionPayload;
import food.delivery.repository.FoodAdditionRepo;
import food.delivery.repository.FoodRepo;
import food.delivery.repository.translate.FoodAdditionTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FoodAdditionService {

    @Autowired
    private FoodAdditionRepo foodAdditionRepo;

    @Autowired
    private FoodRepo foodRepo;

    @Autowired
    private FoodAdditionTranslateRepo foodAdditionTranslateRepo;

    @Transactional
    public void save(List<List<FoodAdditionPayload>> list) {
        list.forEach(payloadList -> {
            Food food = foodRepo.findById(payloadList.get(0).getFoodId()).orElseThrow(() -> new ResourceNotFoundException("category with id does not exist: " + payloadList.get(0).getId()));
            FoodAddition foodAddition = foodAdditionRepo.save(new FoodAddition(food, payloadList.get(0).getPrice()));
            payloadList.forEach(payload -> {
                foodAdditionTranslateRepo.save(new FoodAdditionTranslate(foodAddition, payload.getName(), payload.getLanguage()));
            });
        });
    }

    @Transactional
    public void update(List<List<FoodAdditionPayload>> list) {
        list.forEach(payloadList -> {
            FoodAddition foodAddition = foodAdditionRepo.findById(payloadList.get(0).getId()).orElseThrow(() -> new ResourceNotFoundException("food addition with id does not exist: " + payloadList.get(0).getId()));
            foodAddition.setPrice(payloadList.get(0).getPrice());
            foodAdditionRepo.save(foodAddition);
            payloadList.forEach(payload -> {
                FoodAdditionTranslate foodAdditionTranslate = foodAdditionTranslateRepo.findByLanguageAndFoodAddition_Id(payload.getLanguage(), payload.getId()).orElse(new FoodAdditionTranslate(foodAddition, payload.getName(), payload.getLanguage()));
                foodAdditionTranslate.setName(payload.getName());
                foodAdditionTranslateRepo.save(foodAdditionTranslate);
            });
        });
    }

    @Transactional
    public void delete(Long id) {
        FoodAddition foodAddition = foodAdditionRepo.getById(id);
        foodAdditionTranslateRepo.deleteAll(foodAdditionTranslateRepo.findAllByFoodAddition_Id(id));
        foodAdditionRepo.delete(foodAddition);
    }

    public List<FoodAdditionPayload> getAllWithFoodId(Long foodId) {
        return foodAdditionTranslateRepo.findAllWithFoodId( UserSettings.getLanguage(), foodId);
    }

    public List<FoodAdditionPayload> getWithId(Long id) {
        return foodAdditionTranslateRepo.findWithId( id);
    }


}
