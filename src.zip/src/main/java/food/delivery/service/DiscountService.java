package food.delivery.service;


import food.delivery.entity.Discount;
import food.delivery.entity.translate.DiscountTranslate;
import food.delivery.exceptions.ResourceNotFoundException;
import food.delivery.payloads.DiscountPayload;
import food.delivery.repository.DiscountRepo;
import food.delivery.repository.FoodRepo;
import food.delivery.repository.RestaurantRepo;
import food.delivery.repository.translate.DiscountTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class DiscountService {

    @Autowired
    private DiscountRepo discountRepo;

    @Autowired
    private DiscountTranslateRepo discountTranslateRepo;

    @Autowired
    private FoodRepo foodRepo;

    @Autowired
    private RestaurantRepo restaurantRepo;


    @Transactional
    public void save(List<DiscountPayload> payloadList) {
        Discount discount = discountRepo.save(new Discount(payloadList.get(0).getActive(), payloadList.get(0).getDiscount(), payloadList.get(0).getDiscountReason(), payloadList.get(0).getStartTime(),
                payloadList.get(0).getFinishTime(), payloadList.get(0).getDiscountPercent(), payloadList.get(0).getFreeDelivery(), payloadList.get(0).getCount(), payloadList.get(0).getMinSum(), payloadList.get(0).getMaxSum()));
        payloadList.forEach(payload -> {
            discountTranslateRepo.save(new DiscountTranslate(payload.getName(), payload.getDescription(), payload.getLanguage(), discount));
        });
    }

    @Transactional
    public void update(List<DiscountPayload> payloadList) {
        Discount discount = discountRepo.findById(payloadList.get(0).getId()).orElseThrow(() -> new ResourceNotFoundException("food addition with id does not exist: " + payloadList.get(0).getId()));
        discount.setDiscount(payloadList.get(0).getDiscount());
        discount.setActive(payloadList.get(0).getActive());
        discount.setDiscountReason(payloadList.get(0).getDiscountReason());
        discount.setStartTime(payloadList.get(0).getStartTime());
        discount.setFinishTime(payloadList.get(0).getFinishTime());
        discount.setDiscountPercent(payloadList.get(0).getDiscountPercent());
        discount.setFreeDelivery(payloadList.get(0).getFreeDelivery());
        discount.setCount(payloadList.get(0).getCount());
        discount.setMinSum(payloadList.get(0).getMinSum());
        discount.setMaxSum(payloadList.get(0).getMaxSum());
        discountRepo.save(discount);
        payloadList.forEach(payload -> {
            DiscountTranslate discountTranslate = discountTranslateRepo.findByLanguageAndDiscount_Id(payload.getLanguage(), discount.getId()).orElse(new DiscountTranslate(payload.getName(), payload.getDescription(), payload.getLanguage(), discount));
            discountTranslate.setName(payload.getName());
            discountTranslate.setDescription(payload.getDescription());
            discountTranslateRepo.save(discountTranslate);
        });
    }

    public Page<DiscountPayload> getAll(Integer page, Integer size) {
        return discountTranslateRepo.findAllWithLanguage(PageRequest.of(page, size), UserSettings.getLanguage());
    }

    public List<DiscountPayload> getAllWithRestaurant(Long restaurantId) {
        return discountTranslateRepo.findAllForRestaurant(UserSettings.getLanguage(), restaurantId).stream().peek(discountPayload -> {
            discountPayload.setDiscountedFood(foodRepo.findDiscountedFoodWithDiscountId(UserSettings.getLanguage(), discountPayload.getId(), restaurantId));
            discountPayload.setGiftFood(foodRepo.findGiftedFoodWithDiscountId(UserSettings.getLanguage(), discountPayload.getId(), restaurantId));
        }).collect(Collectors.toList());
    }

    @Transactional
    public void delete(Long discountId) {
        Discount discountByDB = discountRepo.getById(discountId);
        foodRepo.findDiscountedFoodWithOnlyDiscountIdEntity(discountId).stream().peek(food -> {
            food.setDiscounts(new HashSet<>(discountRepo.findAllWithDiscountedFoodId(food.getId()).stream()
                    .filter(discount -> discount.getId().equals(discountId)).collect(Collectors.toList())));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        foodRepo.findGiftedFoodWithOnlyDiscountIdEntity(discountId).stream().peek(food -> {
            food.setGiftDiscounts(new HashSet<>(discountRepo.findGiftDiscountWithDiscountedFoodId(food.getId()).stream()
                    .filter(discount -> discount.getId().equals(discountId)).collect(Collectors.toList())));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        restaurantRepo.findAllWithDiscountId(discountId).stream().peek(restaurant -> {
            Set<Discount> discountSet = discountRepo.findAllWithRestaurantId(restaurant.getId());
            discountSet.remove(discountByDB);
            restaurant.setDiscounts(discountSet);
            restaurantRepo.save(restaurant);
        }).collect(Collectors.toList());

        discountTranslateRepo.deleteAll(discountTranslateRepo.findAllByDiscount_Id(discountId));

        discountRepo.deleteById(discountId);
    }

    public List<DiscountPayload> getWithId(Long id){
        return discountTranslateRepo.findWithId(id);
    }


}
