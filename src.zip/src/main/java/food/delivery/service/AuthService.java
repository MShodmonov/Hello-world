package food.delivery.service;


import food.delivery.entity.Role;
import food.delivery.entity.User;
import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.eums.RoleEnumeration;
import food.delivery.exceptions.BadRequestException;
import food.delivery.repository.RoleRepository;
import food.delivery.repository.UserRepository;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private SMSService smsService;


    private final RestTemplate restTemplate = new RestTemplate();

    public User findUserByUsername(String username) {
        return userRepository.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("Not registered user"));
    }

    public void saveNewUser(String phoneNumber, String fullname) {
        Optional<User> optional = userRepository.findByUsername(phoneNumber);
        if (optional.isPresent())
            if (UserSettings.getLanguage().equals(LanguageEnum.uz))
                throw new BadRequestException("Bu telefon raqam bilan foydalanuvchi tizimda mavjud. ");
            else throw new BadRequestException("Пользователь с таким номером уже существует в системе. ");
        Role userRole = roleRepository.findByName(RoleEnumeration.ROLE_USER);
        userRepository.save(new User(phoneNumber, passwordEncoder.encode("delivery"), Boolean.FALSE, List.of(userRole), fullname));
        smsService.sendMessage(phoneNumber);
    }

    public void saveNewRestaurant(String phoneNumber, String fullname, String password) {
        Optional<User> optional = userRepository.findByUsername(phoneNumber);
        if (optional.isPresent())
            if (UserSettings.getLanguage().equals(LanguageEnum.uz))
                throw new BadRequestException("Bu telefon raqam bilan foydalanuvchi tizimda mavjud. ");
            else throw new BadRequestException("Пользователь с таким номером уже существует в системе. ");
        Role userRole = roleRepository.findByName(RoleEnumeration.ROLE_RESTAURANT);
        userRepository.save(new User(phoneNumber, passwordEncoder.encode(password), Boolean.TRUE, List.of(userRole), fullname));
    }

    public void saveNewDriver(String phoneNumber, String fullname, String password) {
        Optional<User> optional = userRepository.findByUsername(phoneNumber);
        if (optional.isPresent())
            if (UserSettings.getLanguage().equals(LanguageEnum.uz))
                throw new BadRequestException("Bu telefon raqam bilan foydalanuvchi tizimda mavjud. ");
            else throw new BadRequestException("Пользователь с таким номером уже существует в системе. ");
        Role userRole = roleRepository.findByName(RoleEnumeration.ROLE_DRIVER);
        userRepository.save(new User(phoneNumber, passwordEncoder.encode(password), Boolean.TRUE, List.of(userRole), fullname));
    }

    public void activateUser(String code, String phoneNumber) {
        User user = userRepository.findByUsername(phoneNumber).orElseThrow(() -> new BadRequestException("User with phone number has not registered"));
        if (user.getAttemptCount() <= 100) {
            if (passwordEncoder.matches(code, user.getPassword())) {
                user.setIsEnabled(Boolean.TRUE);
                user.setAttemptCount(0);
                user.setRoles(userRepository.getAllRolesWithUserId(user.getId()));
                userRepository.save(user);
            } else {
                user.setAttemptCount(user.getAttemptCount() + 1);
                userRepository.save(user);
                if (UserSettings.getLanguage().equals(LanguageEnum.uz))
                    throw new BadRequestException("Siz kiritgan kod xato iltimos qayta urinib kuring");
                else throw new BadRequestException("Вы ввели неверный код, попробуйте еще раз");
            }
        } else throw new BadRequestException("You have finished your attempt please contact operator");
    }

    public Boolean checkUser(String phoneNumber) {
        Optional<User> optional = userRepository.findByUsername(phoneNumber);
        if (optional.isEmpty())
            return Boolean.FALSE;
        else return Boolean.TRUE;
    }

    public void restoreUser(String phoneNumber) {
        smsService.sendMessage(phoneNumber);
    }


}
