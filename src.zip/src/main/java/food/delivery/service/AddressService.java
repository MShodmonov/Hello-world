package food.delivery.service;


import food.delivery.entity.Address;
import food.delivery.entity.User;
import food.delivery.exceptions.BadRequestException;
import food.delivery.payloads.AddressPayload;
import food.delivery.repository.AddressRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AddressService {

    @Autowired
    private AddressRepo addressRepo;

    ////////////////-------NEEDS-TO-EXPLAIN-TO-FRONT-DEV-----///////////////
    @Transactional
    public void save(AddressPayload payload, User user) {
        addressRepo.saveAll(addressRepo.findAllByUser_IdAndCurrent(user.getId(), Boolean.TRUE).stream().peek(address -> {
            address.setCurrent(Boolean.FALSE);
        }).collect(Collectors.toList()));
        addressRepo.save(new Address(user, payload.getLongitude(), payload.getLatitude(), payload.getAddressTypeEnum(), payload.getBuilding(), payload.getFloor(), payload.getHouse(), Boolean.TRUE));
    }

    @Transactional
    public void delete(Long addressId, User user) {
        if (addressRepo.existsAddressByIdAndUser_Id(addressId, user.getId())) {
            addressRepo.deleteById(addressId);
        } else throw new BadRequestException("You do not have access this resource");
    }

    @Transactional
    public void edit(AddressPayload payload, User user){
        if (addressRepo.existsAddressByIdAndUser_Id(payload.getId(), user.getId())) {
            Address address = addressRepo.getById(payload.getId());
            address.setAddressTypeEnum(payload.getAddressTypeEnum());
            address.setBuilding(payload.getBuilding());
            address.setFloor(payload.getFloor());
            address.setHouse(payload.getHouse());
            address.setLatitude(payload.getLatitude());
        } else throw new BadRequestException("You do not have access this resource");
    }

    @Transactional
    public void makeCurrent(Long addressId, User user){
        if (addressRepo.existsAddressByIdAndUser_Id(addressId, user.getId())) {
            addressRepo.saveAll(addressRepo.findAllByUser_IdAndCurrent(user.getId(), Boolean.TRUE).stream().peek(address -> {
                address.setCurrent(Boolean.FALSE);
            }).collect(Collectors.toList()));
            Address address = addressRepo.getById(addressId);
            address.setCurrent(Boolean.TRUE);
            addressRepo.save(address);
        } else throw new BadRequestException("You do not have access this resource");
    }

    @Transactional
    public List<AddressPayload> getAddresses(User user){
        return addressRepo.findAllWithUserId(user.getId());
    }


}
