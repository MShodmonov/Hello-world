package food.delivery.service;//package food.delivery.service;


import com.google.maps.model.DistanceMatrixElement;
import com.google.maps.model.LatLng;
import food.delivery.entity.Food;
import food.delivery.entity.FoodAddition;
import food.delivery.entity.Restaurant;
import food.delivery.entity.User;
import food.delivery.entity.eums.DiscountEnum;
import food.delivery.entity.eums.DiscountReasonEnum;
import food.delivery.exceptions.BadRequestException;
import food.delivery.payloads.OrderContentPayload;
import food.delivery.payloads.OrderDiscountPayload;
import food.delivery.payloads.OrderPayload;
import food.delivery.repository.*;
import food.delivery.repository.translate.DiscountTranslateRepo;
import food.delivery.repository.translate.FoodAdditionTranslateRepo;
import food.delivery.repository.translate.FoodTranslateRepo;
import food.delivery.utils.UserSettings;
import food.delivery.utils.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private OrderContentRepo orderContentRepo;

    @Autowired
    private OrderDiscountRepo orderDiscountRepo;

    @Autowired
    private DiscountRepo discountRepo;

    @Autowired
    private FoodTranslateRepo foodTranslateRepo;

    @Autowired
    private FoodAdditionRepo foodAdditionRepo;

    @Autowired
    private FoodRepo foodRepo;

    @Autowired
    private DiscountTranslateRepo discountTranslateRepo;

    @Autowired
    private FoodAdditionTranslateRepo foodAdditionTranslateRepo;

    @Autowired
    private GoogleService googleService;

    @Autowired
    private RestaurantRepo restaurantRepo;

    public OrderPayload calculate(OrderPayload payload, User user) {
        Restaurant restaurant = restaurantRepo.findById(payload.getRestaurantId()).orElseThrow(() -> new BadRequestException("Restaurant with id does not exist: " + payload.getRestaurantId()));
        AtomicLong totalSum = new AtomicLong(0L);

        AtomicLong deliveryTime = new AtomicLong(0L);
        AtomicBoolean freeDelivery = new AtomicBoolean(Boolean.FALSE);
        payload.getOrderContentList().stream().peek(orderContent -> {
            String foodName = foodTranslateRepo.getFoodNameWithFoodId(orderContent.getId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + orderContent.getId()));
            Food food = foodRepo.findById(orderContent.getId()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + orderContent.getId()));
            if (deliveryTime.get() < food.getPreparationMinute())
                deliveryTime.set(food.getPreparationMinute());
            Long sum = food.getPrice() * orderContent.getCount();
            orderContent.setPrice(food.getPrice());
            if (orderContent.getFoodAdditionId() != null) {
                FoodAddition foodAddition = foodAdditionRepo.findById(orderContent.getFoodAdditionId()).orElseThrow(() -> new BadRequestException("Food addition with id does not exist: " + orderContent.getFoodAdditionId()));
                foodName = foodName + " " + foodTranslateRepo.getFoodAdditionName(orderContent.getFoodAdditionId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food addition translate with id does not exist: " + orderContent.getFoodAdditionId()));
                sum = sum + foodAddition.getPrice() * orderContent.getCount();
                orderContent.setPrice(orderContent.getPrice() + foodAddition.getPrice());
            }
            orderContent.setName(foodName);
            orderContent.setTotalSum(sum);
            totalSum.set(totalSum.get() + sum);
        }).collect(Collectors.toList());
        payload.setTotalSumContent(totalSum.get());

        DistanceMatrixElement element = null;
        if (!payload.getIsPickUp()) {
            element = googleService.calculateRoute(new LatLng(restaurant.getLatitude(), restaurant.getLongitude()), new LatLng(payload.getLatitude(), payload.getLongitude()));
            payload.setDeliveryTime(deliveryTime.get() + element.duration.inSeconds / 60);
            long l = (long) (Variables.getConstants().getDeliveryCost() * (element.distance.inMeters / 1000D));
            l = l + (100 - l % 100);
            payload.setDeliveryCost(l);
        } else {
            payload.setDeliveryTime(deliveryTime.get());
        }

        discountTranslateRepo.findAllForRestaurant(UserSettings.getLanguage(), payload.getRestaurantId()).forEach(discount -> {
            if (discount.getDiscount().equals(DiscountEnum.FREE_DELIVERY)) {
                if (!(payload.getIsPickUp() || freeDelivery.get())) {
                    if (discount.getCount() == 0 || (orderRepo.countByClient_IdAndRestaurantId(user.getId(), payload.getRestaurantId()) + 1) > discount.getCount()) {
                        if (totalSum.get() > discount.getMinSum()) {
                            if (discount.getMaxSum() > payload.getDeliveryCost()) {
                                freeDelivery.set(Boolean.TRUE);
                                payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), payload.getDeliveryCost(), 0L, discount.getMaxSum()));
                                payload.setDeliveryCost(0L);
                            } else {
                                payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), payload.getDeliveryCost(), payload.getDeliveryCost() - discount.getMaxSum(), discount.getMaxSum()));
                                payload.setDeliveryCost(payload.getDeliveryCost() - discount.getMaxSum());

                            }
                        }
                    }
                }
            } else if (discount.getDiscount().equals(DiscountEnum.PERCENT)) {
                if (discount.getCount() == 0 || (orderRepo.countByClient_IdAndRestaurantId(user.getId(), payload.getRestaurantId()) + 1) > discount.getCount()) {
                    if (totalSum.get() > discount.getMinSum()) {
                        payload.setTotalSumContent(totalSum.get() * (100 - discount.getDiscountPercent()) / 100);
                        payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), totalSum.get(), payload.getTotalSumContent(), discount.getMaxSum()));
                        totalSum.set(payload.getTotalSumContent());
                    }
                }
            } else if (discount.getDiscount().equals(DiscountEnum.ADDITIONAL_FOOD)) {
                if (discount.getCount() == 0 || (orderRepo.countByClient_IdAndRestaurantId(user.getId(), payload.getRestaurantId()) + 1) > discount.getCount()) {
                    if (totalSum.get() > discount.getMinSum()) {
                        foodRepo.findGiftedFoodWithDiscountIdEntity(discount.getId(), payload.getRestaurantId()).forEach(food -> {
                            String foodName = foodTranslateRepo.getFoodNameWithFoodId(food.getId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + food.getId()));
                            payload.getOrderContentList().add(new OrderContentPayload(food.getId(), food.getPrice(), 1, foodName, null, 0L));
                            payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), food.getPrice(), 0L, discount.getMaxSum()));
                        });
                    }
                }
            }
        });
        payload.setSum(payload.getTotalSumContent() + payload.getDeliveryCost());
        return payload;
    }

    public OrderPayload calculateNoAuth(OrderPayload payload) {
        Restaurant restaurant = restaurantRepo.findById(payload.getRestaurantId()).orElseThrow(() -> new BadRequestException("Restaurant with id does not exist: " + payload.getRestaurantId()));
        AtomicLong totalSum = new AtomicLong(0L);

        AtomicLong deliveryTime = new AtomicLong(0L);
        AtomicBoolean freeDelivery = new AtomicBoolean(Boolean.FALSE);
        payload.getOrderContentList().stream().peek(orderContent -> {
            String foodName = foodTranslateRepo.getFoodNameWithFoodId(orderContent.getId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + orderContent.getId()));
            Food food = foodRepo.findById(orderContent.getId()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + orderContent.getId()));
            if (deliveryTime.get() < food.getPreparationMinute())
                deliveryTime.set(food.getPreparationMinute());
            Long sum = food.getPrice() * orderContent.getCount();
            orderContent.setPrice(food.getPrice());
            if (orderContent.getFoodAdditionId() != null) {
                FoodAddition foodAddition = foodAdditionRepo.findById(orderContent.getFoodAdditionId()).orElseThrow(() -> new BadRequestException("Food addition with id does not exist: " + orderContent.getFoodAdditionId()));
                foodName = foodName + " " + foodTranslateRepo.getFoodAdditionName(orderContent.getFoodAdditionId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food addition translate with id does not exist: " + orderContent.getFoodAdditionId()));
                sum = sum + foodAddition.getPrice() * orderContent.getCount();
                orderContent.setPrice(orderContent.getPrice() + foodAddition.getPrice());
            }
            orderContent.setName(foodName);
            orderContent.setTotalSum(sum);
            totalSum.set(totalSum.get() + sum);
        }).collect(Collectors.toList());
        payload.setTotalSumContent(totalSum.get());

        DistanceMatrixElement element = null;
        if (!payload.getIsPickUp()) {
            element = googleService.calculateRoute(new LatLng(restaurant.getLatitude(), restaurant.getLongitude()), new LatLng(payload.getLatitude(), payload.getLongitude()));
            payload.setDeliveryTime(deliveryTime.get() + element.duration.inSeconds / 60);
            long l = (long) (Variables.getConstants().getDeliveryCost() * (element.distance.inMeters / 1000D));
            l = l + (100 - l % 100);
            payload.setDeliveryCost(l);
        } else {
            payload.setDeliveryTime(deliveryTime.get());
        }

        discountTranslateRepo.findAllForRestaurant(UserSettings.getLanguage(), payload.getRestaurantId()).forEach(discount -> {
            if (discount.getDiscount().equals(DiscountEnum.FREE_DELIVERY)) {
                if (!(payload.getIsPickUp() || freeDelivery.get())) {
                    if (!discount.getDiscountReason().equals(DiscountReasonEnum.COUNT)) {
                        if (totalSum.get() > discount.getMinSum()) {
                            if (discount.getMaxSum() > payload.getDeliveryCost()) {
                                freeDelivery.set(Boolean.TRUE);
                                payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), payload.getDeliveryCost(), 0L, discount.getMaxSum()));
                                payload.setDeliveryCost(0L);
                            } else {
                                payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), payload.getDeliveryCost(), payload.getDeliveryCost() - discount.getMaxSum(), discount.getMaxSum()));
                                payload.setDeliveryCost(payload.getDeliveryCost() - discount.getMaxSum());

                            }
                        }
                    }
                }
            } else if (discount.getDiscount().equals(DiscountEnum.PERCENT)) {
                if (!discount.getDiscountReason().equals(DiscountReasonEnum.COUNT)) {
                    if (totalSum.get() > discount.getMinSum()) {
                        payload.setTotalSumContent(totalSum.get() * (100 - discount.getDiscountPercent()) / 100);
                        payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), totalSum.get(), payload.getTotalSumContent(), discount.getMaxSum()));
                        totalSum.set(payload.getTotalSumContent());
                    }
                }
            } else if (discount.getDiscount().equals(DiscountEnum.ADDITIONAL_FOOD)) {
                if (!discount.getDiscountReason().equals(DiscountReasonEnum.COUNT)) {
                    if (totalSum.get() > discount.getMinSum()) {
                        foodRepo.findGiftedFoodWithDiscountIdEntity(discount.getId(), payload.getRestaurantId()).forEach(food -> {
                            String foodName = foodTranslateRepo.getFoodNameWithFoodId(food.getId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + food.getId()));
                            payload.getOrderContentList().add(new OrderContentPayload(food.getId(), food.getPrice(), 1, foodName, null, 0L));
                            payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), food.getPrice(), 0L, discount.getMaxSum()));
                        });
                    }
                }
            }
        });
        payload.setSum(payload.getTotalSumContent() + payload.getDeliveryCost());
        return payload;
    }


}
