package food.delivery.service;


import food.delivery.entity.Food;
import food.delivery.entity.FoodAddition;
import food.delivery.entity.User;
import food.delivery.entity.eums.DiscountEnum;
import food.delivery.exceptions.BadRequestException;
import food.delivery.payloads.OrderDiscountPayload;
import food.delivery.payloads.OrderPayload;
import food.delivery.repository.*;
import food.delivery.repository.translate.DiscountTranslateRepo;
import food.delivery.repository.translate.FoodAdditionTranslateRepo;
import food.delivery.repository.translate.FoodTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private OrderContentRepo orderContentRepo;

    @Autowired
    private OrderDiscountRepo orderDiscountRepo;

    @Autowired
    private DiscountRepo discountRepo;

    @Autowired
    private FoodTranslateRepo foodTranslateRepo;

    @Autowired
    private FoodAdditionRepo foodAdditionRepo;

    @Autowired
    private FoodRepo foodRepo;

    @Autowired
    private DiscountTranslateRepo discountTranslateRepo;

    @Autowired
    private FoodAdditionTranslateRepo foodAdditionTranslateRepo;

    public OrderPayload calculate(OrderPayload payload, User user) {
        AtomicLong totalSum = new AtomicLong(0L);
        AtomicBoolean freeDelivery = new AtomicBoolean(Boolean.FALSE);
        payload.getOrderContentList().stream().peek(orderContent -> {
            String foodName = foodTranslateRepo.getFoodNameWithFoodId(orderContent.getId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + orderContent.getId()));
            Food food = foodRepo.findById(orderContent.getId()).orElseThrow(() -> new BadRequestException("Food with id does not exist: " + orderContent.getId()));
            Long sum = food.getPrice() * orderContent.getCount();
            orderContent.setPrice(food.getPrice());
            if (orderContent.getFoodAdditionId() != null) {
                FoodAddition foodAddition = foodAdditionRepo.findById(orderContent.getFoodAdditionId()).orElseThrow(() -> new BadRequestException("Food addition with id does not exist: " + orderContent.getFoodAdditionId()));
                foodName = foodName + " " + foodTranslateRepo.getFoodAdditionName(orderContent.getFoodAdditionId(), UserSettings.getLanguage()).orElseThrow(() -> new BadRequestException("Food addition translate with id does not exist: " + orderContent.getFoodAdditionId()));
                sum = sum + foodAddition.getPrice() * orderContent.getCount();
                orderContent.setPrice(orderContent.getPrice() + foodAddition.getPrice());
            }
            orderContent.setName(foodName);
            orderContent.setTotalSum(sum);
            totalSum.set(totalSum.get() + sum);
        }).collect(Collectors.toList());

        Long orderCost = totalSum.get();

        discountTranslateRepo.findAllForRestaurant(UserSettings.getLanguage(), payload.getRestaurantId()).forEach(discount -> {
            if (discount.getDiscount().equals(DiscountEnum.FREE_DELIVERY)) {
                if (discount.getCount() == 0) {
                    if (totalSum.get() > discount.getMinSum()) {
                        freeDelivery.set(Boolean.TRUE);
                        payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), orderCost, totalSum.get()));
                    }
                } else {
                    if ((orderRepo.countByClient_IdAndRestaurantId(user.getId(), payload.getRestaurantId()) + 1) > discount.getCount()) {
                        if (totalSum.get() > discount.getMinSum()) {
                            freeDelivery.set(Boolean.TRUE);
                            payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), orderCost, totalSum.get()));
                        }
                    }

                }
            } else if (discount.getDiscount().equals(DiscountEnum.PERCENT)) {
                if (discount.getCount() == 0) {
                    if (totalSum.get() > discount.getMinSum()) {
                        totalSum.set(totalSum.get() * (100 - discount.getDiscountPercent()) / 100);
                        payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), orderCost, totalSum.get()));
                    }
                } else {
                    if ((orderRepo.countByClient_IdAndRestaurantId(user.getId(), payload.getRestaurantId()) + 1) > discount.getCount()) {
                        if (totalSum.get() > discount.getMinSum()) {
                            totalSum.set(totalSum.get() * (100 - discount.getDiscountPercent()) / 100);
                            payload.getOrderDiscountList().add(new OrderDiscountPayload(discount.getId(), discount.getName(), discount.getDiscount(), discount.getDiscountReason(), discount.getDiscountPercent(), discount.getCount(), discount.getMinSum(), orderCost, totalSum.get()));
                        }
                    }
                }
            } else if (discount.getDiscount().equals(DiscountEnum.ADDITIONAL_FOOD)) {
                if (discount.getCount() == 0) {
                    if (totalSum.get() > discount.getMinSum()) {

                    }
                } else {
                    if ((orderRepo.countByClient_IdAndRestaurantId(user.getId(), payload.getRestaurantId()) + 1) > discount.getCount()) {
                        if (totalSum.get() > discount.getMinSum()) {

                        }
                    }

                }
            }
        });


        return null;
    }


}
