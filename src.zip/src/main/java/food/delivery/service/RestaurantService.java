package food.delivery.service;


import com.google.maps.errors.ApiException;
import com.google.maps.model.LatLng;
import food.delivery.entity.Discount;
import food.delivery.entity.Restaurant;
import food.delivery.entity.User;
import food.delivery.entity.translate.RestaurantTranslate;
import food.delivery.exceptions.ResourceNotFoundException;
import food.delivery.payloads.DiscountRestaurantPayload;
import food.delivery.payloads.RestaurantPayload;
import food.delivery.payloads.UserPayload;
import food.delivery.repository.*;
import food.delivery.repository.translate.RestaurantTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class RestaurantService {

    @Autowired
    private RestaurantRepo restaurantRepo;

    @Autowired
    private RestaurantTranslateRepo restaurantTranslateRepo;

    @Autowired
    private FoodRepo foodRepo;

    @Autowired
    private DiscountRepo discountRepo;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GoogleService googleService;

    @Autowired
    private RoleRepository roleRepository;

    @Transactional
    public void saveAll(List<List<RestaurantPayload>> list) {
        list.forEach(payloadList -> {
            Restaurant restaurant = restaurantRepo.save(new Restaurant(payloadList.get(0).getImageUrl(), payloadList.get(0).getLongitude(), payloadList.get(0).getLatitude(), payloadList.get(0).getActive(), payloadList.get(0).getOpenTime(), payloadList.get(0).getCloseTime()));
            payloadList.forEach(payload -> {
                restaurantTranslateRepo.save(new RestaurantTranslate(restaurant, payload.getName(), payload.getLanguage(), payload.getDescription()));
            });
        });
    }

    public Page<RestaurantPayload> getAll(Integer page, Integer size) {
        return restaurantTranslateRepo.getAllRestaurantsWithLanguage(PageRequest.of(page, size), UserSettings.getLanguage());
    }

    public Page<RestaurantPayload> getAllWithDistance(Integer page, Integer size, Double longitude, Double latitude) throws IOException, InterruptedException, ApiException {
        PageRequest of = PageRequest.of(page, size);
        List<RestaurantPayload> list = restaurantTranslateRepo.getAllRestaurantsWithLanguage(of, UserSettings.getLanguage()).toList();
        return new PageImpl<>(googleService.calculateDistance(list, new LatLng(latitude, longitude)), of, list.size());
    }


    @Transactional
    public void updateAll(List<List<RestaurantPayload>> list) {
        list.forEach(payloadList -> {
            Restaurant restaurant = restaurantRepo.findById(payloadList.get(0).getId()).orElseThrow(() -> new ResourceNotFoundException("restaurant with id does not exist: " + payloadList.get(0).getId()));
            restaurant.setActive(payloadList.get(0).getActive());
            restaurant.setLatitude(payloadList.get(0).getLatitude());
            restaurant.setImageUrl(payloadList.get(0).getImageUrl());
            restaurant.setLongitude(payloadList.get(0).getLongitude());
            restaurant.setCloseTime(payloadList.get(0).getCloseTime());
            restaurant.setOpenTime(payloadList.get(0).getOpenTime());
            restaurantRepo.save(restaurant);
            payloadList.forEach(payload -> {
                RestaurantTranslate restaurantTranslate = restaurantTranslateRepo.findByLanguageAndRestaurant_Id(payload.getLanguage(), payload.getId()).orElse(new RestaurantTranslate(restaurant, payload.getName(), payload.getLanguage(), payload.getDescription()));
                restaurantTranslate.setName(payload.getName());
                restaurantTranslate.setDescription(payload.getDescription());
                restaurantTranslateRepo.save(restaurantTranslate);
            });
        });
    }

    @Transactional
    public void delete(Long id) {
        Restaurant restaurant = restaurantRepo.getById(id);
        restaurantTranslateRepo.deleteAll(restaurantTranslateRepo.findAllByRestaurant_Id(id));
        restaurantRepo.delete(restaurant);
    }


    @Transactional
    public void deleteDiscountFromRestaurant(Long discountId, Long restaurantId) {
        Restaurant restaurant = restaurantRepo.getById(restaurantId);
        foodRepo.findDiscountedFoodWithDiscountIdEntity(discountId, restaurantId).stream().peek(food -> {
            food.setDiscounts(new HashSet<>(discountRepo.findAllWithDiscountedFoodId(food.getId()).stream()
                    .filter(discount -> discount.getId().equals(discountId)).collect(Collectors.toList())));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        foodRepo.findGiftedFoodWithDiscountIdEntity(discountId, restaurantId).stream().peek(food -> {
            food.setGiftDiscounts(new HashSet<>(discountRepo.findGiftDiscountWithDiscountedFoodId(food.getId()).stream()
                    .filter(discount -> discount.getId().equals(discountId)).collect(Collectors.toList())));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        Set<Discount> discountSet = discountRepo.findAllWithRestaurantId(restaurantId);
        discountSet.remove(discountRepo.getById(discountId));
        restaurant.setDiscounts(discountSet);
        restaurantRepo.save(restaurant);
    }


    //////////////////--------------------NEEDS-TO-BE----CHECKED-------------///////////////////
    @Transactional
    public void editDiscount(DiscountRestaurantPayload payload) {
        Discount discountByDB = discountRepo.getById(payload.getDiscountId());
        Restaurant restaurant = restaurantRepo.getById(payload.getRestaurantId());
        foodRepo.findDiscountedFoodWithDiscountIdEntity(payload.getDiscountId(), payload.getRestaurantId()).stream().peek(food -> {
            food.setDiscounts(new HashSet<>(discountRepo.findAllWithDiscountedFoodId(food.getId()).stream()
                    .filter(discount -> discount.getId().equals(payload.getDiscountId())).collect(Collectors.toList())));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        foodRepo.findGiftedFoodWithDiscountIdEntity(payload.getDiscountId(), payload.getRestaurantId()).stream().peek(food -> {
            food.setGiftDiscounts(new HashSet<>(discountRepo.findGiftDiscountWithDiscountedFoodId(food.getId()).stream()
                    .filter(discount -> discount.getId().equals(payload.getDiscountId())).collect(Collectors.toList())));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        foodRepo.findAllWithId(payload.getDiscountedFoodId()).stream().peek(food -> {
            List<Discount> discountList = discountRepo.findAllWithDiscountedFoodId(food.getId());
            discountList.add(discountByDB);
            food.setDiscounts(new HashSet<>(discountList));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        foodRepo.findAllWithId(payload.getGiftedFoodId()).stream().peek(food -> {
            List<Discount> discountList = discountRepo.findGiftDiscountWithDiscountedFoodId(food.getId());
            discountList.add(discountByDB);
            food.setDiscounts(new HashSet<>(discountList));
            foodRepo.save(food);
        }).collect(Collectors.toList());

        Set<Discount> restaurantDiscounts = discountRepo.findAllWithRestaurantId(payload.getRestaurantId());
        if (!restaurantDiscounts.contains(discountByDB))
            restaurantDiscounts.add(discountByDB);
        restaurant.setDiscounts(restaurantDiscounts);
        restaurantRepo.save(restaurant);


    }

    @Transactional
    public void setManager(String phoneNumber, Long restaurantId) {
        Restaurant restaurant = restaurantRepo.findById(restaurantId).orElseThrow(() -> new ResourceNotFoundException("restaurant with id does not exist: " + restaurantId));
        User manager = userRepository.findByUsername(phoneNumber).orElseThrow(() -> new ResourceNotFoundException("user with phone number does not exist: " + phoneNumber));
        restaurant.setManagerId(manager.getId());
        manager.setRestaurantId(restaurantId);
        userRepository.save(manager);
        restaurantRepo.save(restaurant);
    }

    public UserPayload getManager(Long restaurantId){
        UserPayload userPayload = userRepository.findWithRestaurantId(restaurantId).orElseThrow(() -> new ResourceNotFoundException("restaurant does not have manager yet"));
        userPayload.setRoles(roleRepository.getUserRoles(userPayload.getId()));
        return userPayload;
    }

    public List<RestaurantPayload> getWithId(Long id){
        return restaurantTranslateRepo.getWithId(id);
    }
}
