package food.delivery.service;


import food.delivery.entity.ProjectConstants;
import food.delivery.repository.ConstantsRepo;
import food.delivery.utils.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class ConstantsService {

    @Autowired
    private ConstantsRepo constantsRepo;

    @Transactional
    public void saveOrUpdate(ProjectConstants constant) {
        if (constantsRepo.count() == 0) {
            Variables.setConstants(constantsRepo.save(new ProjectConstants(constant.getDeliveryCost())));
        } else {
            ProjectConstants constantDB = constantsRepo.findAll().get(0);
            constantDB.setDeliveryCost(constant.getDeliveryCost());
            Variables.setConstants(constantsRepo.save(constantDB));
        }
    }

    public ProjectConstants get(){
        return constantsRepo.findAll().get(0);
    }

}
