package food.delivery.payloads;


import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FoodPayload {

    private Long id;

    private String imageUrl;

    private Long price;

    private String name;

    private LanguageEnum language;

    private Long restaurantId;

    private Long localCategoryId;

    private Long categoryId;

    private String description;

    private Long preparationMinute;

    public FoodPayload(Long id, String imageUrl, Long price, String name, LanguageEnum language, Long preparationMinute) {
        this.id = id;
        this.imageUrl = imageUrl;
        this.price = price;
        this.name = name;
        this.language = language;
        this.preparationMinute = preparationMinute;
    }
}
