package food.delivery.payloads;

import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FoodPayloadAdmin {

    private Long id;

    private String imageUrl;

    private Long price;

    private String name;

    private LanguageEnum language;

    private Long localCategoryId;

    private String localCategoryName;

    private Long categoryId;

    private String categoryName;

    private String description;

    private Long preparationMinute;
}
