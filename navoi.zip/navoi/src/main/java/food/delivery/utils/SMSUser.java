package food.delivery.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SMSUser {

   private Long id;

   private String name;

   private String email;

   private String status;

   private String sms_api_login;

   private String sms_api_password;

   private String uz_price;

   private Long balance;

   private Integer is_vip;
}
