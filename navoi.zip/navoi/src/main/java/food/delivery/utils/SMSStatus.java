package food.delivery.utils;

public enum SMSStatus {

    TRANSMTD,
    DELIVRD,
    UNDELIV,
    EXPIRED,
    REJECTD,
    DELETED,
    NOT_WORKING,
    WORKING

}
