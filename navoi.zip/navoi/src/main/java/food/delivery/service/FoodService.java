package food.delivery.service;


import food.delivery.entity.Category;
import food.delivery.entity.Food;
import food.delivery.entity.LocalCategory;
import food.delivery.entity.Restaurant;
import food.delivery.entity.translate.FoodTranslate;
import food.delivery.exceptions.ResourceNotFoundException;
import food.delivery.payloads.FoodPayload;
import food.delivery.repository.CategoryRepo;
import food.delivery.repository.FoodRepo;
import food.delivery.repository.LocalCategoryRepo;
import food.delivery.repository.RestaurantRepo;
import food.delivery.repository.translate.FoodTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FoodService {

    @Autowired
    private FoodRepo foodRepo;

    @Autowired
    private FoodTranslateRepo translateRepo;

    @Autowired
    private RestaurantRepo restaurantRepo;

    @Autowired
    private LocalCategoryRepo localCategoryRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Transactional
    public void save(List<List<FoodPayload>> list) {
        list.forEach(payloadList -> {
            Restaurant restaurant = restaurantRepo.findById(payloadList.get(0).getRestaurantId()).orElseThrow(() -> new ResourceNotFoundException(" restaurant with id does not exist: " + payloadList.get(0).getRestaurantId()));
            LocalCategory localCategory = localCategoryRepo.findById(payloadList.get(0).getLocalCategoryId()).orElseThrow(() -> new ResourceNotFoundException(" Local category with id does not exist: " + payloadList.get(0).getLocalCategoryId()));
            Category category = categoryRepo.findById(payloadList.get(0).getCategoryId()).orElseThrow(() -> new ResourceNotFoundException("  category with id does not exist: " + payloadList.get(0).getCategoryId()));
            Food food = foodRepo.save(new Food(payloadList.get(0).getImageUrl(), payloadList.get(0).getPrice(), category, localCategory, restaurant, payloadList.get(0).getPreparationMinute()));
            payloadList.forEach(payload -> {
                translateRepo.save(new FoodTranslate(food, payload.getName(), payload.getLanguage(), payload.getDescription()));
            });
        });
    }

    @Transactional
    public void update(List<List<FoodPayload>> list) {
        list.forEach(payloadList -> {
            LocalCategory localCategory = localCategoryRepo.findById(payloadList.get(0).getLocalCategoryId()).orElseThrow(() -> new ResourceNotFoundException(" Local category with id does not exist: " + payloadList.get(0).getLocalCategoryId()));
            Category category = categoryRepo.findById(payloadList.get(0).getCategoryId()).orElseThrow(() -> new ResourceNotFoundException("  category with id does not exist: " + payloadList.get(0).getCategoryId()));
            Food food = foodRepo.findById(payloadList.get(0).getId()).orElseThrow(() -> new ResourceNotFoundException("  Food with id does not exist: " + payloadList.get(0).getId()));
            food.setCategory(category);
            food.setLocalCategory(localCategory);
            food.setImageUrl(payloadList.get(0).getImageUrl());
            food.setPrice(payloadList.get(0).getPrice());
            food.setPreparationMinute(payloadList.get(0).getPreparationMinute());
            foodRepo.save(food);
            payloadList.forEach(payload -> {
                FoodTranslate foodTranslate = translateRepo.findByLanguageAndFood_Id(payload.getLanguage(), payload.getId()).orElse(new FoodTranslate(food, payload.getName(), payload.getLanguage(), payload.getDescription()));
                foodTranslate.setName(payload.getName());
                foodTranslate.setDescription(payload.getDescription());
                translateRepo.save(foodTranslate);
            });
        });
    }

    @Transactional
    public void delete(Long id){
        Food food = foodRepo.getById(id);
        translateRepo.deleteAll(translateRepo.findAllByFood_Id(id));
        foodRepo.delete(food);
    }

    Page<FoodPayload> getAllWithRestaurantId(Long restaurantId, Integer page, Integer size){
       return translateRepo.findAllWithRestaurantIdAndLanguage(PageRequest.of(page, size), restaurantId, UserSettings.getLanguage());
    }

    Page<FoodPayload> getAllWithRestaurantIdOperator(Long restaurantId, Integer page, Integer size){
        return translateRepo.findAllWithRestaurantIdAndLanguageOperator(PageRequest.of(page, size), restaurantId, UserSettings.getLanguage());
    }
}
