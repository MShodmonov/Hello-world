package food.delivery.service;


import food.delivery.entity.Restaurant;
import food.delivery.entity.translate.RestaurantTranslate;
import food.delivery.exceptions.ResourceNotFoundException;
import food.delivery.payloads.RestaurantPayload;
import food.delivery.repository.RestaurantRepo;
import food.delivery.repository.translate.RestaurantTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RestaurantService {

    @Autowired
    private RestaurantRepo restaurantRepo;

    @Autowired
    private RestaurantTranslateRepo restaurantTranslateRepo;

    @Transactional
    public void saveAll(List<List<RestaurantPayload>> list){
        list.forEach(payloadList -> {
            Restaurant restaurant = restaurantRepo.save(new Restaurant(payloadList.get(0).getImageUrl(), payloadList.get(0).getLongitude(), payloadList.get(0).getLatitude(), payloadList.get(0).getActive(), payloadList.get(0).getOpenTime(), payloadList.get(0).getCloseTime()));
            payloadList.forEach(payload -> {
                restaurantTranslateRepo.save(new RestaurantTranslate(restaurant, payload.getName(), payload.getLanguage(), payload.getDescription()));
            });
        });
    }

    public Page<RestaurantPayload> getAll(Integer page, Integer size){
        return restaurantTranslateRepo.getAllRestaurantsWithLanguage(PageRequest.of(page, size), UserSettings.getLanguage());
    }

    @Transactional
    public void updateAll(List<List<RestaurantPayload>> list){
        list.forEach(payloadList -> {
            Restaurant restaurant = restaurantRepo.findById(payloadList.get(0).getId()).orElseThrow(() -> new ResourceNotFoundException("restaurant with id does not exist: " + payloadList.get(0).getId()));
            restaurant.setActive(payloadList.get(0).getActive());
            restaurant.setLatitude(payloadList.get(0).getLatitude());
            restaurant.setImageUrl(payloadList.get(0).getImageUrl());
            restaurant.setLongitude(payloadList.get(0).getLongitude());
            restaurant.setCloseTime(payloadList.get(0).getCloseTime());
            restaurant.setOpenTime(payloadList.get(0).getOpenTime());
            restaurantRepo.save(restaurant);
            payloadList.forEach(payload -> {
                RestaurantTranslate restaurantTranslate = restaurantTranslateRepo.findByLanguageAndRestaurant_Id(payload.getLanguage(), payload.getId()).orElse(new RestaurantTranslate(restaurant, payload.getName(), payload.getLanguage(), payload.getDescription()));
                restaurantTranslate.setName(payload.getName());
                restaurantTranslate.setDescription(payload.getDescription());
                restaurantTranslateRepo.save(restaurantTranslate);
            });
        });
    }

    @Transactional
    public void delete(Long id){
        Restaurant restaurant = restaurantRepo.getById(id);
        restaurantTranslateRepo.deleteAll(restaurantTranslateRepo.findAllByRestaurant_Id(id));
        restaurantRepo.delete(restaurant);
    }
}
