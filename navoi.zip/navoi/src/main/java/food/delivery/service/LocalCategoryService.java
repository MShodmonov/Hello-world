package food.delivery.service;


import food.delivery.entity.LocalCategory;
import food.delivery.entity.translate.LocalCategoryTranslates;
import food.delivery.exceptions.ResourceNotFoundException;
import food.delivery.payloads.LocalCategoryPayload;
import food.delivery.repository.LocalCategoryRepo;
import food.delivery.repository.translate.LocalCategoryTranslateRepo;
import food.delivery.utils.UserSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class LocalCategoryService {

    @Autowired
    private LocalCategoryRepo localCategoryRepo;

    @Autowired
    private LocalCategoryTranslateRepo translateRepo;


    @Transactional
    public void save(List<LocalCategoryPayload> list){
        LocalCategory localCategory = localCategoryRepo.save(new LocalCategory());
        list.forEach(payload -> {
            translateRepo.save(new LocalCategoryTranslates(localCategory, payload.getName(), payload.getLanguageEnum()));
        });
    }

    @Transactional
    public void update(List<LocalCategoryPayload> list){
        LocalCategory localCategory = localCategoryRepo.findById(list.get(0).getId()).orElseThrow(() -> new ResourceNotFoundException(" Local Category with id does not exist: " + list.get(0).getId()));
        list.forEach(payload -> {
            LocalCategoryTranslates localCategoryTranslates = translateRepo.findByLanguageAndLocalCategory_Id(payload.getLanguageEnum(), payload.getId()).orElse(new LocalCategoryTranslates(localCategory, payload.getName(), payload.getLanguageEnum()));
            localCategoryTranslates.setName(payload.getName());
            translateRepo.save(localCategoryTranslates);
        });
    }

    @Transactional
    public void delete(Long id){
        LocalCategory localCategory = localCategoryRepo.getById(id);
        translateRepo.deleteAll(translateRepo.findAllByLocalCategory_Id(id));
        localCategoryRepo.delete(localCategory);
    }

    public Page<LocalCategoryPayload> getAll(Integer page, Integer size){
        return translateRepo.findAllWithLanguage(PageRequest.of(page, size), UserSettings.getLanguage());
    }

    public List<LocalCategoryPayload> getAllWithRestaurantId(Long restaurantId){
        return translateRepo.findAllWithRestaurantId(UserSettings.getLanguage(), restaurantId);
    }
}
