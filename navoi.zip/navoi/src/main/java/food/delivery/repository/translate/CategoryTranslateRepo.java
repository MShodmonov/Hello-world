package food.delivery.repository.translate;

import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.translate.CategoryTranslate;
import food.delivery.payloads.CategoryPayload;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface CategoryTranslateRepo extends JpaRepository<CategoryTranslate, Long> {

    @Query("select new food.delivery.payloads.CategoryPayload(c.id, ct.name, ct.language, c.imageUrl) from Category c join c.categoryTranslates ct where ct.language=?1 order by ct.name asc ")
    Page<CategoryPayload> getAllCategoriesWithLanguage(Pageable pageable, LanguageEnum languageEnum);

    Optional<CategoryTranslate> findByLanguageAndCategory_Id( LanguageEnum languageEnum, Long categoryId);

    List<CategoryTranslate> findByCategory_Id(Long categoryId);
}
