package food.delivery.repository.translate;

import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.translate.FoodAdditionTranslate;
import food.delivery.payloads.FoodAdditionPayload;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface FoodAdditionTranslateRepo extends JpaRepository<FoodAdditionTranslate, Long> {

    Optional<FoodAdditionTranslate> findByLanguageAndFoodAddition_Id(LanguageEnum languageEnum, Long foodAdditionId);

    List<FoodAdditionTranslate> findAllByFoodAddition_Id(Long foodAdditionId);

    @Query("select new food.delivery.payloads.FoodAdditionPayload(fa.id, fa.price, fat.name) from FoodAddition fa join fa.foodAdditionTranslates fat where fat.language=?1 and fa.food.id=?2")
    Page<FoodAdditionPayload> findAllWithFoodId(Pageable pageable, LanguageEnum languageEnum, Long foodId);
}
