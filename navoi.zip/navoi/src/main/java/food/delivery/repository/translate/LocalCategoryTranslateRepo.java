package food.delivery.repository.translate;

import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.translate.LocalCategoryTranslates;
import food.delivery.payloads.LocalCategoryPayload;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface LocalCategoryTranslateRepo  extends JpaRepository<LocalCategoryTranslates, Long> {

    @Query("select new food.delivery.payloads.LocalCategoryPayload(l.id, lt.name, lt.language) from LocalCategory l join l.localCategoryTranslates lt where lt.language=?1 order by lt.name asc")
    Page<LocalCategoryPayload> findAllWithLanguage(Pageable pageable, LanguageEnum languageEnum);

    Optional<LocalCategoryTranslates> findByLanguageAndLocalCategory_Id(LanguageEnum languageEnum, Long localCategoryId);

    List<LocalCategoryTranslates> findAllByLocalCategory_Id(Long localCategoryId);

    @Query("select new food.delivery.payloads.LocalCategoryPayload(lc.id, lct.name, lct.language) from LocalCategory lc join lc.localCategoryTranslates lct join lc.foods f join f.restaurant r where lct.language=?1 and r.id=?2")
    List<LocalCategoryPayload> findAllWithRestaurantId(LanguageEnum languageEnum, Long restaurantId);
}
