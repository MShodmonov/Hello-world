package food.delivery.repository.translate;

import food.delivery.entity.eums.LanguageEnum;
import food.delivery.entity.translate.FoodTranslate;
import food.delivery.payloads.FoodPayload;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface FoodTranslateRepo extends JpaRepository<FoodTranslate, Long> {

    @Query("select new food.delivery.payloads.FoodPayload(f.id, f.imageUrl, f.price, ft.name, ft.language, f.preparationMinute) from Food f join f.foodTranslates ft where ft.language=?2 and f.restaurant.id=?1")
    Page<FoodPayload> findAllWithRestaurantIdAndLanguage(Pageable pageable, Long restaurantId, LanguageEnum languageEnum);

    @Query("select new food.delivery.payloads.FoodPayloadAdmin( f.id, f.imageUrl, f.price, ft.name, ft.language, f.localCategory.id, lct.name, f.category.id, ct.name, ft.description, f.preparationMinute) from Food f join f.foodTranslates ft join f.category.categoryTranslates ct join f.localCategory.localCategoryTranslates lct where ft.language=?2 and ct.language=?2 and lct.language=?2 and f.restaurant.id=?1")
    Page<FoodPayload> findAllWithRestaurantIdAndLanguageOperator(Pageable pageable, Long restaurantId, LanguageEnum languageEnum);

    Optional<FoodTranslate> findByLanguageAndFood_Id(LanguageEnum languageEnum, Long foodId);

    List<FoodTranslate> findAllByFood_Id(Long id);
}
