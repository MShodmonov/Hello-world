package food.delivery.entity;


import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.translate.FoodAdditionTranslate;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class FoodAddition extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private Food food;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @OneToMany(mappedBy = "foodAddition")
    private List<FoodAdditionTranslate> foodAdditionTranslates;

    private Long price;

    public FoodAddition(Food food, Long price) {
        this.food = food;
        this.price = price;
    }
}
