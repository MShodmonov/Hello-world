package food.delivery.entity.translate;

import food.delivery.entity.FoodAddition;
import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.LanguageEnum;
import lombok.*;

import javax.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class FoodAdditionTranslate extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @ManyToOne
    private FoodAddition foodAddition;

    private String name;

    @Enumerated(EnumType.STRING)
    private LanguageEnum language;

    public FoodAdditionTranslate(FoodAddition foodAddition, String name, LanguageEnum language) {
        this.foodAddition = foodAddition;
        this.name = name;
        this.language = language;
    }
}
