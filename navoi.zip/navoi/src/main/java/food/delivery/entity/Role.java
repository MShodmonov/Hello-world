package food.delivery.entity;

import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.RoleEnumeration;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


import javax.persistence.*;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "roles")
public class Role extends AbstractEntity {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "roleSeq")
    @SequenceGenerator(name = "roleSeq", sequenceName = "role_seq ", allocationSize = 1)
    private Long id;

    @Enumerated(EnumType.STRING)
    private RoleEnumeration name;

    @ManyToMany(mappedBy = "roles")
    private List<User> users;


    public Role(RoleEnumeration name) {
        this.name = name;
    }
}