package food.delivery.entity.translate;


import food.delivery.entity.LocalCategory;
import food.delivery.entity.abstractEntity.AbstractEntity;
import food.delivery.entity.eums.LanguageEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LocalCategoryTranslates extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private LocalCategory localCategory;

    private String name;

    @Enumerated(EnumType.STRING)
    private LanguageEnum language;

    public LocalCategoryTranslates(LocalCategory localCategory, String name, LanguageEnum language) {
        this.localCategory = localCategory;
        this.name = name;
        this.language = language;
    }
}
