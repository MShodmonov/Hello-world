package food.delivery.security;




import food.delivery.entity.User;
import food.delivery.payloads.AuthResponseDto;
import food.delivery.utils.DefaultData;
import food.delivery.utils.TokenInfo;
import food.delivery.utils.TokenStore;
import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;


@Component
public class JwtTokenProvider {

    @Value("${jwt.token.secret}")
    private String secret;

    @Value("${jwt.token.expired}")
    private long expiresIn;

    @Value("${jwt.token.refresh.expired}")
    private long refreshExpiresIn;

    @Value("${jwt.token.type}")
    private String tokenType;

    @Autowired
    private JwtUserDetailsService jwtUserDetailsService;

    @PostConstruct
    protected void init() {
        secret = Base64.getEncoder().encodeToString(secret.getBytes());
    }

    public AuthResponseDto createToken(User user) {

        TokenStore.removeInvalidTokens();

        String tokenId = UUID.randomUUID().toString();

        String refreshToken = generateRefreshToken(user, tokenId);
        String accessToken = generateAccessToken(user, tokenId);

        TokenInfo tokenInfo = new TokenInfo(tokenId, user.getId().toString(), accessToken, expiresIn,
                refreshToken, refreshExpiresIn);

        TokenStore.add(tokenInfo);

        return new AuthResponseDto(accessToken, expiresIn, refreshExpiresIn, refreshToken, tokenType);
    }

    private String generateAccessToken(User user, String tokenId) {

        Claims claims = Jwts.claims().setSubject(user.getUsername());
        claims.put("id", user.getId());
        claims.put("tokenId", tokenId);

        Date now = new Date();
        Date validity = new Date(now.getTime() + expiresIn);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(validity)
                .signWith(SignatureAlgorithm.HS256, secret)
                .compact();
    }

    private String generateRefreshToken(User user, String tokenId) {

        Claims claims = Jwts.claims().setSubject(user.getUsername());
        claims.put("tokenId", tokenId);
        claims.put("id", user.getId());

        Date now = new Date();
        Date validity = new Date(now.getTime() + refreshExpiresIn);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(validity)
                .signWith(SignatureAlgorithm.HS256, secret)
                .compact();
    }

    public Authentication getAuthentication(String token) {
        UserDetails userDetails = this.jwtUserDetailsService.loadUserByUsername(getUsername(token));
        return new UsernamePasswordAuthenticationToken(userDetails, "", userDetails.getAuthorities());
    }

    public String getUsername(String token) {
        return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody().getSubject();
    }

    public DefaultData getDefaultDataFromToken(String token) {
        Claims claims = Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();

        String username = claims.getSubject();
        String userId = claims.get("id", Long.class).toString();
        String tokenId = claims.get("tokenId", String.class);

        return new DefaultData(userId, username, tokenId);
    }

    public String resolveToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        return null;
    }

    public boolean validateToken(String token) throws JwtException, IllegalArgumentException {
        Jws<Claims> claimsJws = Jwts.parser().setSigningKey(secret).parseClaimsJws(token);
        return !claimsJws.getBody().getExpiration().before(new Date());
    }

    public long getExpiresIn() {
        return expiresIn;
    }

    public long getRefreshExpiresIn() {
        return refreshExpiresIn;
    }

    public String getTokenType() {
        return tokenType;
    }
}