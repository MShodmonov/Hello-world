package uz.medbooking.websocketserver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;
import uz.medbooking.websocketserver.dto.Message;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/websocket")
public class WsController {

    @Autowired
    SimpMessagingTemplate template;

    @PostMapping("/send")
    public Boolean send(@RequestBody Message textMessage) {
        template.convertAndSend("/topic/messages", textMessage);
        return Boolean.TRUE;
    }

    @PostMapping("/send/moderator")
    public Boolean sendModerator(@RequestBody Message textMessage) {
        template.convertAndSend("/topic/moderator", textMessage);
        return Boolean.TRUE;
    }

    @PostMapping("/send/reception")
    public Boolean sendReception(@RequestBody Message textMessage) {
        template.convertAndSend("/topic/reception", textMessage);
        return Boolean.TRUE;
    }

    @PostMapping("/send/doctor")
    public Boolean sendDoctor(@RequestBody Message textMessage) {
        template.convertAndSend("/topic/doctor", textMessage);
        return Boolean.TRUE;
    }

    @PostMapping("/send/user")
    public Boolean senduser(@RequestBody Message textMessage) {
        template.convertAndSend("/topic/user", textMessage);
        return Boolean.TRUE;
    }

    @PostMapping("/send/schedule")
    public Boolean sendSchedule(@RequestBody Message textMessage) {
        template.convertAndSend("/topic/schedule", textMessage);
        return Boolean.TRUE;
    }

    @PostMapping("/send/user/v2/{serviceId}")
    public Boolean senduser2(@RequestBody Message textMessage, @PathVariable UUID serviceId) {
        template.convertAndSend("/topic/user/v2/"+serviceId.toString(), textMessage);
        return Boolean.TRUE;
    }



    @MessageMapping("/sendMessage")
    @SendTo("/topic/messages")
    public Message sendMessage(Message message) {
        return message;
    }

    @MessageMapping("/sendMessageModerator")
    @SendTo("/topic/moderator")
    public Message sendMessageModerator(Message message) {
        return message;
    }

    @MessageMapping("/sendMessageReception")
    @SendTo("/topic/reception")
    public Message sendMessageReception(Message message) {
        return message;
    }

    @MessageMapping("/sendMessageDoctor")
    @SendTo("/topic/doctor")
    public Message sendMessageDoctor(Message message) {
        return message;
    }

    @MessageMapping("/sendMessageUser")
    @SendTo("/topic/user")
    public Message sendMessageUser(Message message) {
        return message;
    }

    @MessageMapping("/sendMessageSchedule")
    @SendTo("/topic/schedule")
    public Message sendMessageScheduleUpdate(Message message) {
        return message;
    }

    @MessageMapping("/mb-websocket/{serviceId}")
    @SendTo("/topic/user/v2/{serviceId}")
    public void sendMessageUser(@DestinationVariable String serviceId) {

    }





}
