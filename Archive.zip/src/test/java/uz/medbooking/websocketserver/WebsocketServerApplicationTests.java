package uz.medbooking.websocketserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
